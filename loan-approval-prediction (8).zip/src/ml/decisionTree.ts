import { FeatureImportance } from '../types';

interface TreeNode {
  isLeaf: boolean;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
  probability: number; // probability of class 1 (Approved)
  prediction: number;
  samples: number;
  impurity: number;
}

export class DecisionTreeClassifier {
  root: TreeNode | null = null;
  maxDepth: number;
  minSamplesSplit: number;
  featureNames: string[];
  featureImportances: number[] = [];

  constructor(featureNames: string[] = [], maxDepth = 5, minSamplesSplit = 8) {
    this.featureNames = featureNames;
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
  }

  private calculateGini(y: number[]): number {
    const total = y.length;
    if (total === 0) return 0;
    const p1 = y.filter(val => val === 1).length / total;
    const p0 = 1 - p1;
    return 1 - (p1 * p1 + p0 * p0);
  }

  fit(X: number[][], y: number[]): void {
    const nFeatures = X[0]?.length || 0;
    this.featureImportances = new Array(nFeatures).fill(0);
    this.root = this.buildTree(X, y, 0);

    // Normalize feature importances
    const totalImp = this.featureImportances.reduce((a, b) => a + b, 0);
    if (totalImp > 0) {
      this.featureImportances = this.featureImportances.map(val => val / totalImp);
    }
  }

  private buildTree(X: number[][], y: number[], depth: number): TreeNode {
    const samples = y.length;
    const p1 = samples > 0 ? y.filter(val => val === 1).length / samples : 0;
    const prediction = p1 >= 0.5 ? 1 : 0;
    const impurity = this.calculateGini(y);

    // Stop conditions
    if (depth >= this.maxDepth || samples < this.minSamplesSplit || impurity === 0) {
      return {
        isLeaf: true,
        probability: Number(p1.toFixed(4)),
        prediction,
        samples,
        impurity,
      };
    }

    let bestGain = 0;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestSplits: { leftX: number[][]; leftY: number[]; rightX: number[][]; rightY: number[] } | null = null;

    const nFeatures = X[0].length;

    for (let f = 0; f < nFeatures; f++) {
      // Find candidate thresholds (e.g. 10 percentiles or unique values)
      const values = X.map(row => row[f]);
      const uniqueVals = Array.from(new Set(values)).sort((a, b) => a - b);
      if (uniqueVals.length <= 1) continue;

      // Select candidate thresholds
      const candidateThresholds: number[] = [];
      const step = Math.max(1, Math.floor(uniqueVals.length / 10));
      for (let i = 0; i < uniqueVals.length - 1; i += step) {
        candidateThresholds.push((uniqueVals[i] + uniqueVals[i + 1]) / 2);
      }

      for (const threshold of candidateThresholds) {
        const leftIdx: number[] = [];
        const rightIdx: number[] = [];

        for (let i = 0; i < samples; i++) {
          if (X[i][f] <= threshold) leftIdx.push(i);
          else rightIdx.push(i);
        }

        if (leftIdx.length === 0 || rightIdx.length === 0) continue;

        const leftY = leftIdx.map(i => y[i]);
        const rightY = rightIdx.map(i => y[i]);

        const leftGini = this.calculateGini(leftY);
        const rightGini = this.calculateGini(rightY);

        const weightedGini = (leftY.length / samples) * leftGini + (rightY.length / samples) * rightGini;
        const gain = impurity - weightedGini;

        if (gain > bestGain) {
          bestGain = gain;
          bestFeature = f;
          bestThreshold = threshold;
          bestSplits = {
            leftX: leftIdx.map(i => X[i]),
            leftY,
            rightX: rightIdx.map(i => X[i]),
            rightY,
          };
        }
      }
    }

    if (bestGain <= 0.001 || !bestSplits) {
      return {
        isLeaf: true,
        probability: Number(p1.toFixed(4)),
        prediction,
        samples,
        impurity,
      };
    }

    // Accumulate Gini importance
    this.featureImportances[bestFeature] += samples * bestGain;

    const leftNode = this.buildTree(bestSplits.leftX, bestSplits.leftY, depth + 1);
    const rightNode = this.buildTree(bestSplits.rightX, bestSplits.rightY, depth + 1);

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: leftNode,
      right: rightNode,
      probability: Number(p1.toFixed(4)),
      prediction,
      samples,
      impurity,
    };
  }

  predictProbability(x: number[]): number {
    if (!this.root) return 0.5;
    let node: TreeNode = this.root;
    while (!node.isLeaf) {
      if (node.featureIndex !== undefined && node.threshold !== undefined) {
        if (x[node.featureIndex] <= node.threshold) {
          if (node.left) node = node.left;
          else break;
        } else {
          if (node.right) node = node.right;
          else break;
        }
      } else {
        break;
      }
    }
    return node.probability;
  }

  predict(x: number[], threshold = 0.5): number {
    return this.predictProbability(x) >= threshold ? 1 : 0;
  }

  getFeatureImportances(): FeatureImportance[] {
    const importances: FeatureImportance[] = [];
    const maxImp = Math.max(...this.featureImportances, 0.0001);

    const friendlyLabels: Record<string, string> = {
      applicant_income: 'Applicant Income',
      coapplicant_income: 'Coapplicant Income',
      total_income: 'Total Combined Income',
      loan_amount: 'Loan Amount',
      loan_term: 'Loan Term (Months)',
      applicant_age: 'Applicant Age',
      dependents: 'Number of Dependents',
      existing_loans: 'Existing Loans Count',
      monthly_debt: 'Monthly Debt Obligation',
      debt_to_income: 'Debt-to-Income (DTI) Ratio',
      loan_to_income: 'Loan-to-Income (LTI) Ratio',
      credit_history: 'Credit History Score',
      education_graduate: 'Graduate Education',
      self_employed_yes: 'Self-Employed Status',
      existing_loans_indicator: 'Has Existing Loans',
      emp_salaried: 'Employment: Salaried',
      emp_self_employed: 'Employment: Self-Employed',
      emp_business: 'Employment: Business',
      emp_contract: 'Employment: Contract',
      marital_married: 'Marital: Married',
      marital_single: 'Marital: Single',
      marital_divorced: 'Marital: Divorced',
      area_urban: 'Property: Urban',
      area_semiurban: 'Property: Semiurban',
      area_rural: 'Property: Rural',
      type_single_family: 'Property Type: Single Family',
      type_apartment: 'Property Type: Apartment',
      type_townhouse: 'Property Type: Townhouse',
      type_condo: 'Property Type: Condo',
      purpose_home_purchase: 'Purpose: Home Purchase',
      purpose_home_improvement: 'Purpose: Home Improvement',
      purpose_debt_consolidation: 'Purpose: Debt Consolidation',
      purpose_education: 'Purpose: Education',
      purpose_business: 'Purpose: Business',
    };

    for (let i = 0; i < this.featureImportances.length; i++) {
      const name = this.featureNames[i] || `Feature ${i}`;
      const raw = this.featureImportances[i] || 0;
      importances.push({
        feature: name,
        label: friendlyLabels[name] || name,
        importance: Number((raw / maxImp).toFixed(3)),
        rawCoefficient: Number(raw.toFixed(4)),
        direction: 'positive',
      });
    }

    return importances.sort((a, b) => b.importance - a.importance);
  }
}
