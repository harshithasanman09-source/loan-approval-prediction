import { EngineeredLoanRecord, FeatureEncodingMap, LoanApplicantInput } from '../types';
import { engineerApplicantInput } from './featureEngineering';

export interface FittedEncoder {
  featureNames: string[];
  encode: (record: EngineeredLoanRecord | LoanApplicantInput) => number[];
  standardize: (features: number[]) => number[];
  featureMap: FeatureEncodingMap;
}

export function fitEncoder(records: EngineeredLoanRecord[]): FittedEncoder {
  // Extract distinct categorical values from training data to avoid hardcoding
  const employmentCategories = Array.from(new Set(records.map(r => r.employment_status))).sort();
  const maritalCategories = Array.from(new Set(records.map(r => r.marital_status))).sort();
  const propertyAreaCategories = Array.from(new Set(records.map(r => r.property_area))).sort();
  const propertyTypeCategories = Array.from(new Set(records.map(r => r.property_type))).sort();
  const loanPurposeCategories = Array.from(new Set(records.map(r => r.loan_purpose))).sort();

  const numericCols = [
    'applicant_income',
    'coapplicant_income',
    'total_income',
    'loan_amount',
    'loan_term',
    'applicant_age',
    'dependents',
    'existing_loans',
    'monthly_debt',
    'debt_to_income',
    'loan_to_income',
  ];

  // Calculate means and standard deviations for numeric features
  const numericMeans: Record<string, number> = {};
  const numericStds: Record<string, number> = {};

  for (const col of numericCols) {
    const vals = records.map(r => (r as unknown as Record<string, number>)[col] || 0);
    const sum = vals.reduce((a, b) => a + b, 0);
    const mean = sum / (vals.length || 1);
    const variance = vals.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (vals.length || 1);
    const std = Math.sqrt(variance) || 1;
    numericMeans[col] = mean;
    numericStds[col] = std;
  }

  // Feature names list
  const featureNames: string[] = [
    ...numericCols,
    'credit_history',
    'education_graduate',
    'self_employed_yes',
    'existing_loans_indicator',
    ...employmentCategories.map(c => `emp_${c.toLowerCase().replace(/\s+/g, '_')}`),
    ...maritalCategories.map(c => `marital_${c.toLowerCase().replace(/\s+/g, '_')}`),
    ...propertyAreaCategories.map(c => `area_${c.toLowerCase().replace(/\s+/g, '_')}`),
    ...propertyTypeCategories.map(c => `type_${c.toLowerCase().replace(/\s+/g, '_')}`),
    ...loanPurposeCategories.map(c => `purpose_${c.toLowerCase().replace(/\s+/g, '_')}`),
  ];

  const featureMap: FeatureEncodingMap = {
    featureNames,
    categoricalIndices: {
      employment: employmentCategories,
      marital: maritalCategories,
      propertyArea: propertyAreaCategories,
      propertyType: propertyTypeCategories,
      loanPurpose: loanPurposeCategories,
    },
    numericMeans,
    numericStds,
    numericCols,
  };

  const encode = (data: EngineeredLoanRecord | LoanApplicantInput): number[] => {
    // If it's a LoanApplicantInput without pre-computed engineered features:
    let total_income = (data as EngineeredLoanRecord).total_income;
    let debt_to_income = (data as EngineeredLoanRecord).debt_to_income;
    let loan_to_income = (data as EngineeredLoanRecord).loan_to_income;
    let existing_loans_indicator = (data as EngineeredLoanRecord).existing_loans_indicator;

    if (total_income === undefined || debt_to_income === undefined || loan_to_income === undefined) {
      const eng = engineerApplicantInput(data as LoanApplicantInput);
      total_income = eng.total_income;
      debt_to_income = eng.debt_to_income;
      loan_to_income = eng.loan_to_income;
      existing_loans_indicator = eng.existing_loans_indicator;
    }

    const vector: number[] = [];

    // 1. Numeric values (raw)
    const rawNumeric: Record<string, number> = {
      applicant_income: data.applicant_income,
      coapplicant_income: data.coapplicant_income,
      total_income,
      loan_amount: data.loan_amount,
      loan_term: data.loan_term,
      applicant_age: data.applicant_age,
      dependents: data.dependents,
      existing_loans: data.existing_loans,
      monthly_debt: data.monthly_debt,
      debt_to_income,
      loan_to_income,
    };

    for (const col of numericCols) {
      vector.push(rawNumeric[col] ?? 0);
    }

    // 2. Binary encoded features
    vector.push(data.credit_history === 1 ? 1 : 0);
    vector.push(data.education === 'Graduate' ? 1 : 0);
    vector.push(data.self_employed === 'Yes' ? 1 : 0);
    vector.push(existing_loans_indicator ?? (data.existing_loans > 0 ? 1 : 0));

    // 3. One-hot categories
    for (const cat of employmentCategories) {
      vector.push(data.employment_status === cat ? 1 : 0);
    }
    for (const cat of maritalCategories) {
      vector.push(data.marital_status === cat ? 1 : 0);
    }
    for (const cat of propertyAreaCategories) {
      vector.push(data.property_area === cat ? 1 : 0);
    }
    for (const cat of propertyTypeCategories) {
      vector.push(data.property_type === cat ? 1 : 0);
    }
    for (const cat of loanPurposeCategories) {
      vector.push(data.loan_purpose === cat ? 1 : 0);
    }

    return vector;
  };

  // Standardize the numeric columns of a vector (leaves one-hot & binary 0/1 intact)
  const standardize = (features: number[]): number[] => {
    const result = [...features];
    for (let i = 0; i < numericCols.length; i++) {
      const col = numericCols[i];
      const mean = numericMeans[col];
      const std = numericStds[col];
      result[i] = (result[i] - mean) / std;
    }
    return result;
  };

  return {
    featureNames,
    encode,
    standardize,
    featureMap,
  };
}
