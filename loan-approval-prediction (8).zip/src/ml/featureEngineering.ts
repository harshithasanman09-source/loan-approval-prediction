import { CleanLoanRecord, EngineeredLoanRecord, LoanApplicantInput } from '../types';

export function getAgeGroup(age: number): '18-25' | '26-35' | '36-45' | '46-55' | '56+' {
  if (age <= 25) return '18-25';
  if (age <= 35) return '26-35';
  if (age <= 45) return '36-45';
  if (age <= 55) return '46-55';
  return '56+';
}

export function getIncomeGroup(totalIncome: number): 'Low (<$4k)' | 'Moderate ($4k-$7k)' | 'High ($7k-$12k)' | 'Very High ($12k+)' {
  if (totalIncome < 4000) return 'Low (<$4k)';
  if (totalIncome < 7000) return 'Moderate ($4k-$7k)';
  if (totalIncome < 12000) return 'High ($7k-$12k)';
  return 'Very High ($12k+)';
}

export function getLoanAmountGroup(loanAmount: number): 'Small (<$100k)' | 'Medium ($100k-$250k)' | 'Large ($250k-$450k)' | 'Jumbo ($450k+)' {
  if (loanAmount < 100) return 'Small (<$100k)';
  if (loanAmount < 250) return 'Medium ($100k-$250k)';
  if (loanAmount < 450) return 'Large ($250k-$450k)';
  return 'Jumbo ($450k+)';
}

export function engineerRecordFeatures(record: CleanLoanRecord): EngineeredLoanRecord {
  const total_income = Math.max(0, record.applicant_income + record.coapplicant_income);
  const monthlyIncome = total_income > 0 ? (total_income / 12) : 1;
  const debt_to_income = Number((record.monthly_debt / monthlyIncome).toFixed(4));
  const loan_to_income = total_income > 0 ? Number(((record.loan_amount * 1000) / total_income).toFixed(2)) : 0;

  return {
    ...record,
    total_income,
    debt_to_income,
    loan_to_income,
    age_group: getAgeGroup(record.applicant_age),
    income_group: getIncomeGroup(total_income),
    loan_amount_group: getLoanAmountGroup(record.loan_amount),
    existing_loans_indicator: record.existing_loans > 0 ? 1 : 0,
    credit_history_indicator: record.credit_history === 1 ? 1 : 0,
  };
}

export function engineerAllRecords(records: CleanLoanRecord[]): EngineeredLoanRecord[] {
  return records.map(engineerRecordFeatures);
}

export function engineerApplicantInput(input: LoanApplicantInput): {
  total_income: number;
  debt_to_income: number;
  loan_to_income: number;
  existing_loans_indicator: number;
  credit_history_indicator: number;
} {
  const total_income = Math.max(0, input.applicant_income + input.coapplicant_income);
  const monthlyIncome = total_income > 0 ? (total_income / 12) : 1;
  const debt_to_income = Number((input.monthly_debt / monthlyIncome).toFixed(4));
  const loan_to_income = total_income > 0 ? Number(((input.loan_amount * 1000) / total_income).toFixed(2)) : 0;

  return {
    total_income,
    debt_to_income,
    loan_to_income,
    existing_loans_indicator: input.existing_loans > 0 ? 1 : 0,
    credit_history_indicator: input.credit_history === 1 ? 1 : 0,
  };
}
