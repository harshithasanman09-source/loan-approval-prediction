import { FeatureImportance } from '../types';

export class LogisticRegressionModel {
  weights: number[] = [];
  bias = 0;
  featureNames: string[] = [];

  constructor(featureNames: string[] = []) {
    this.featureNames = featureNames;
  }

  sigmoid(z: number): number {
    if (z > 20) return 1;
    if (z < -20) return 0;
    return 1 / (1 + Math.exp(-z));
  }

  fit(
    X: number[][],
    y: number[],
    options: {
      learningRate?: number;
      epochs?: number;
      l2Regularization?: number;
    } = {}
  ): void {
    const { learningRate = 0.08, epochs = 350, l2Regularization = 0.005 } = options;
    const m = X.length;
    if (m === 0) return;
    const n = X[0].length;

    // Initialize weights with small random or zero values
    this.weights = new Array(n).fill(0);
    this.bias = 0;

    // Gradient descent with L2 penalty
    for (let epoch = 0; epoch < epochs; epoch++) {
      const dw = new Array(n).fill(0);
      let db = 0;

      for (let i = 0; i < m; i++) {
        const xi = X[i];
        let z = this.bias;
        for (let j = 0; j < n; j++) {
          z += this.weights[j] * xi[j];
        }
        const pred = this.sigmoid(z);
        const error = pred - y[i];

        db += error;
        for (let j = 0; j < n; j++) {
          dw[j] += error * xi[j];
        }
      }

      // Update weights and bias
      for (let j = 0; j < n; j++) {
        const regGradient = l2Regularization * this.weights[j];
        this.weights[j] -= learningRate * ((dw[j] / m) + regGradient);
      }
      this.bias -= learningRate * (db / m);
    }
  }

  predictProbability(x: number[]): number {
    let z = this.bias;
    for (let j = 0; j < this.weights.length; j++) {
      z += (this.weights[j] || 0) * (x[j] || 0);
    }
    return this.sigmoid(z);
  }

  predict(x: number[], threshold = 0.5): number {
    return this.predictProbability(x) >= threshold ? 1 : 0;
  }

  getFeatureImportances(): FeatureImportance[] {
    const importances: FeatureImportance[] = [];
    const maxAbs = Math.max(...this.weights.map(w => Math.abs(w)), 0.0001);

    const friendlyLabels: Record<string, string> = {
      applicant_income: 'Applicant Income',
      coapplicant_income: 'Coapplicant Income',
      total_income: 'Total Combined Income',
      loan_amount: 'Loan Amount',
      loan_term: 'Loan Term (Months)',
      applicant_age: 'Applicant Age',
      dependents: 'Number of Dependents',
      existing_loans: 'Existing Loans Count',
      monthly_debt: 'Monthly Debt Obligation',
      debt_to_income: 'Debt-to-Income (DTI) Ratio',
      loan_to_income: 'Loan-to-Income (LTI) Ratio',
      credit_history: 'Credit History Score',
      education_graduate: 'Graduate Education',
      self_employed_yes: 'Self-Employed Status',
      existing_loans_indicator: 'Has Existing Loans',
      emp_salaried: 'Employment: Salaried',
      emp_self_employed: 'Employment: Self-Employed',
      emp_business: 'Employment: Business',
      emp_contract: 'Employment: Contract',
      marital_married: 'Marital: Married',
      marital_single: 'Marital: Single',
      marital_divorced: 'Marital: Divorced',
      area_urban: 'Property: Urban',
      area_semiurban: 'Property: Semiurban',
      area_rural: 'Property: Rural',
      type_single_family: 'Property Type: Single Family',
      type_apartment: 'Property Type: Apartment',
      type_townhouse: 'Property Type: Townhouse',
      type_condo: 'Property Type: Condo',
      purpose_home_purchase: 'Purpose: Home Purchase',
      purpose_home_improvement: 'Purpose: Home Improvement',
      purpose_debt_consolidation: 'Purpose: Debt Consolidation',
      purpose_education: 'Purpose: Education',
      purpose_business: 'Purpose: Business',
    };

    for (let i = 0; i < this.weights.length; i++) {
      const name = this.featureNames[i] || `Feature ${i}`;
      const raw = this.weights[i];
      const magnitude = Math.abs(raw);
      importances.push({
        feature: name,
        label: friendlyLabels[name] || name,
        importance: Number((magnitude / maxAbs).toFixed(3)),
        rawCoefficient: Number(raw.toFixed(4)),
        direction: raw >= 0 ? 'positive' : 'negative',
      });
    }

    // Sort descending by importance
    return importances.sort((a, b) => b.importance - a.importance);
  }
}
