import {
  EngineeredLoanRecord,
  ModelEvaluationResult,
  LoanApplicantInput,
  PredictionResultData,
  LoanStatus
} from '../types';
import { fitEncoder, FittedEncoder } from './encoding';
import { LogisticRegressionModel } from './logisticRegression';
import { DecisionTreeClassifier } from './decisionTree';
import { calculateMetrics } from '../utils/metrics';

export interface TrainedModelSuite {
  encoder: FittedEncoder;
  logisticModel: LogisticRegressionModel;
  decisionTreeModel: DecisionTreeClassifier;
  evaluation: ModelEvaluationResult;
  predict: (
    input: LoanApplicantInput,
    modelType?: 'Logistic Regression' | 'Decision Tree',
    threshold?: number
  ) => PredictionResultData;
}

export function trainModels(records: EngineeredLoanRecord[]): TrainedModelSuite {
  // Stratified 80/20 train/test split
  const approved = records.filter(r => r.target === 1);
  const rejected = records.filter(r => r.target === 0);

  // Deterministic shuffle with seed for reproducibility
  const shuffle = <T>(array: T[]): T[] => {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor((Math.sin(i * 997 + 13) * 10000) % (i + 1));
      const idx = Math.abs(j);
      [arr[i], arr[idx]] = [arr[idx], arr[i]];
    }
    return arr;
  };

  const shuffledApp = shuffle(approved);
  const shuffledRej = shuffle(rejected);

  const trainAppCount = Math.floor(shuffledApp.length * 0.8);
  const trainRejCount = Math.floor(shuffledRej.length * 0.8);

  const trainRecords = [
    ...shuffledApp.slice(0, trainAppCount),
    ...shuffledRej.slice(0, trainRejCount)
  ];
  const testRecords = [
    ...shuffledApp.slice(trainAppCount),
    ...shuffledRej.slice(trainRejCount)
  ];

  // Fit encoder strictly on training set to prevent data leakage
  const encoder = fitEncoder(trainRecords);

  // Prepare train and test feature matrices
  const X_train_raw = trainRecords.map(r => encoder.encode(r));
  const X_train_std = X_train_raw.map(r => encoder.standardize(r));
  const y_train = trainRecords.map(r => r.target);

  const X_test_raw = testRecords.map(r => encoder.encode(r));
  const X_test_std = X_test_raw.map(r => encoder.standardize(r));
  const y_test = testRecords.map(r => r.target);

  // 1. Train Logistic Regression
  const logisticModel = new LogisticRegressionModel(encoder.featureNames);
  logisticModel.fit(X_train_std, y_train, {
    learningRate: 0.12,
    epochs: 450,
    l2Regularization: 0.005,
  });

  // Test set evaluation for Logistic Regression
  const lrProbs = X_test_std.map(x => logisticModel.predictProbability(x));
  const lrPreds = lrProbs.map(p => (p >= 0.5 ? 1 : 0));
  const lrMetrics = calculateMetrics(y_test, lrPreds, lrProbs);
  const lrImportances = logisticModel.getFeatureImportances();

  // 2. Train Decision Tree
  const decisionTreeModel = new DecisionTreeClassifier(encoder.featureNames, 5, 8);
  decisionTreeModel.fit(X_train_raw, y_train);

  // Test set evaluation for Decision Tree
  const dtProbs = X_test_raw.map(x => decisionTreeModel.predictProbability(x));
  const dtPreds = dtProbs.map(p => (p >= 0.5 ? 1 : 0));
  const dtMetrics = calculateMetrics(y_test, dtPreds, dtProbs);
  const dtImportances = decisionTreeModel.getFeatureImportances();

  // Determine best model based on composite F1 and Accuracy
  const lrScore = lrMetrics.f1Score * 0.6 + lrMetrics.accuracy * 0.4;
  const dtScore = dtMetrics.f1Score * 0.6 + dtMetrics.accuracy * 0.4;
  const bestModelName: 'Logistic Regression' | 'Decision Tree' =
    lrScore >= dtScore ? 'Logistic Regression' : 'Decision Tree';

  const evaluation: ModelEvaluationResult = {
    logisticRegression: {
      metrics: lrMetrics,
      featureImportances: lrImportances,
      testProbabilities: testRecords.map((r, i) => ({
        actual: r.target,
        predicted: lrPreds[i],
        prob: lrProbs[i],
      })),
    },
    decisionTree: {
      metrics: dtMetrics,
      featureImportances: dtImportances,
      testProbabilities: testRecords.map((r, i) => ({
        actual: r.target,
        predicted: dtPreds[i],
        prob: dtProbs[i],
      })),
    },
    bestModelName,
    splitRatio: {
      trainCount: trainRecords.length,
      testCount: testRecords.length,
    },
  };

  // Inference prediction function
  const predict = (
    input: LoanApplicantInput,
    modelType: 'Logistic Regression' | 'Decision Tree' = bestModelName,
    threshold = 0.5
  ): PredictionResultData => {
    const rawVector = encoder.encode(input);
    let approvalProb = 0;

    if (modelType === 'Logistic Regression') {
      const stdVector = encoder.standardize(rawVector);
      approvalProb = logisticModel.predictProbability(stdVector);
    } else {
      approvalProb = decisionTreeModel.predictProbability(rawVector);
    }

    approvalProb = Number(Math.max(0.01, Math.min(0.99, approvalProb)).toFixed(4));
    const rejectionProb = Number((1 - approvalProb).toFixed(4));
    const isApproved = approvalProb >= threshold;
    const predictedStatus: LoanStatus = isApproved ? 'Approved' : 'Rejected';

    // Confidence is distance from threshold / boundary
    const confidence = Number((Math.max(approvalProb, rejectionProb) * 100).toFixed(1));

    // Interpretation categorization
    let interpretation: 'High Approval Probability' | 'Moderate Probability' | 'Low Approval Probability';
    let interpretationDescription: string;

    if (approvalProb >= 0.70) {
      interpretation = 'High Approval Probability';
      interpretationDescription =
        'The model estimates a relatively high probability of approval based on patterns learned from the historical dataset.';
    } else if (approvalProb >= 0.40) {
      interpretation = 'Moderate Probability';
      interpretationDescription =
        'The model estimates an uncertain approval outcome. The application falls closer to the classification threshold.';
    } else {
      interpretation = 'Low Approval Probability';
      interpretationDescription =
        'The model estimates a relatively low probability of approval based on patterns learned from the historical dataset.';
    }

    // Top contributing factors for this applicant
    const topContributingFactors: Array<{
      name: string;
      impact: 'positive' | 'negative';
      description: string;
    }> = [];

    if (input.credit_history === 1) {
      topContributingFactors.push({
        name: 'Credit History',
        impact: 'positive',
        description: 'Meets credit guidelines with no major delinquency record.',
      });
    } else {
      topContributingFactors.push({
        name: 'Credit History',
        impact: 'negative',
        description: 'Past default or lack of established satisfactory credit record.',
      });
    }

    const totalInc = input.applicant_income + input.coapplicant_income;
    const monthlyInc = totalInc > 0 ? totalInc / 12 : 1;
    const dti = input.monthly_debt / monthlyInc;
    if (dti <= 0.35) {
      topContributingFactors.push({
        name: 'Debt-to-Income (DTI)',
        impact: 'positive',
        description: `Healthy DTI ratio of ${(dti * 100).toFixed(1)}% shows strong repayment buffer.`,
      });
    } else if (dti > 0.48) {
      topContributingFactors.push({
        name: 'Debt-to-Income (DTI)',
        impact: 'negative',
        description: `Elevated DTI ratio of ${(dti * 100).toFixed(1)}% increases financial strain risk.`,
      });
    }

    const lti = (input.loan_amount * 1000) / (totalInc || 1);
    if (lti <= 3.2) {
      topContributingFactors.push({
        name: 'Loan-to-Income (LTI)',
        impact: 'positive',
        description: `Moderate leverage ratio of ${lti.toFixed(1)}x annual household income.`,
      });
    } else if (lti > 4.5) {
      topContributingFactors.push({
        name: 'Loan-to-Income (LTI)',
        impact: 'negative',
        description: `High requested borrowing multiple of ${lti.toFixed(1)}x annual household income.`,
      });
    }

    if (input.education === 'Graduate') {
      topContributingFactors.push({
        name: 'Education Level',
        impact: 'positive',
        description: 'Graduate degree correlates with stable long-term earning potential.',
      });
    }

    if (input.existing_loans >= 3) {
      topContributingFactors.push({
        name: 'Existing Credit Obligations',
        impact: 'negative',
        description: `${input.existing_loans} concurrent active loans elevate credit exposure.`,
      });
    }

    return {
      predictedStatus,
      approvalProbability: Number((approvalProb * 100).toFixed(1)),
      rejectionProbability: Number((rejectionProb * 100).toFixed(1)),
      confidence,
      modelUsed: modelType,
      threshold,
      interpretation,
      interpretationDescription,
      topContributingFactors,
      inputData: input,
      timestamp: new Date().toISOString(),
    };
  };

  return {
    encoder,
    logisticModel,
    decisionTreeModel,
    evaluation,
    predict,
  };
}
