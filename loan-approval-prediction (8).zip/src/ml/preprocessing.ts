import { RawLoanRecord, CleanLoanRecord, LoanStatus } from '../types';

function calculateMedian(numbers: number[]): number {
  if (numbers.length === 0) return 0;
  const sorted = [...numbers].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function calculateMode<T extends string | number>(values: T[]): T {
  if (values.length === 0) return '' as unknown as T;
  const counts = new Map<T, number>();
  let maxCount = 0;
  let mode = values[0];
  for (const v of values) {
    const c = (counts.get(v) || 0) + 1;
    counts.set(v, c);
    if (c > maxCount) {
      maxCount = c;
      mode = v;
    }
  }
  return mode;
}

export function parseTargetStatus(val: unknown): { status: LoanStatus; numeric: number } | null {
  if (val === undefined || val === null) return null;
  const s = String(val).trim().toLowerCase();
  if (['approved', 'yes', 'y', '1', 'true'].includes(s)) {
    return { status: 'Approved', numeric: 1 };
  }
  if (['rejected', 'no', 'n', '0', 'false'].includes(s)) {
    return { status: 'Rejected', numeric: 0 };
  }
  return null;
}

export function cleanAndPreprocessData(rawRecords: RawLoanRecord[]): CleanLoanRecord[] {
  // Step 1: Collect valid values for imputation calculations
  const rawValidIncomes: number[] = [];
  const rawValidCoIncomes: number[] = [];
  const rawValidLoans: number[] = [];
  const rawValidTerms: number[] = [];
  const rawValidAges: number[] = [];
  const rawValidDebts: number[] = [];
  const rawValidCreditHistories: number[] = [];
  const rawValidDependents: number[] = [];
  const rawValidExistingLoans: number[] = [];

  const rawEducations: string[] = [];
  const rawMarital: string[] = [];
  const rawEmployment: string[] = [];
  const rawSelfEmployed: string[] = [];
  const rawPropertyArea: string[] = [];
  const rawPropertyType: string[] = [];
  const rawLoanPurposes: string[] = [];

  for (const r of rawRecords) {
    const inc = Number(r.applicant_income);
    if (!isNaN(inc) && inc >= 0) rawValidIncomes.push(inc);

    const coinc = Number(r.coapplicant_income);
    if (!isNaN(coinc) && coinc >= 0) rawValidCoIncomes.push(coinc);

    const loan = Number(r.loan_amount);
    if (!isNaN(loan) && loan > 0) rawValidLoans.push(loan);

    const term = Number(r.loan_term);
    if (!isNaN(term) && term > 0) rawValidTerms.push(term);

    const age = Number(r.applicant_age);
    if (!isNaN(age) && age >= 18 && age <= 100) rawValidAges.push(age);

    const debt = Number(r.monthly_debt);
    if (!isNaN(debt) && debt >= 0) rawValidDebts.push(debt);

    const ch = Number(r.credit_history);
    if (!isNaN(ch) && (ch === 0 || ch === 1)) rawValidCreditHistories.push(ch);

    const dep = Number(r.dependents);
    if (!isNaN(dep) && dep >= 0) rawValidDependents.push(dep);

    const ex = Number(r.existing_loans);
    if (!isNaN(ex) && ex >= 0) rawValidExistingLoans.push(ex);

    if (r.education) rawEducations.push(String(r.education).trim());
    if (r.marital_status) rawMarital.push(String(r.marital_status).trim());
    if (r.employment_status) rawEmployment.push(String(r.employment_status).trim());
    if (r.self_employed) rawSelfEmployed.push(String(r.self_employed).trim());
    if (r.property_area) rawPropertyArea.push(String(r.property_area).trim());
    if (r.property_type) rawPropertyType.push(String(r.property_type).trim());
    if (r.loan_purpose) rawLoanPurposes.push(String(r.loan_purpose).trim());
  }

  // Medians & Modes for imputation
  const medianIncome = calculateMedian(rawValidIncomes) || 4500;
  const medianCoIncome = calculateMedian(rawValidCoIncomes) || 0;
  const medianLoan = calculateMedian(rawValidLoans) || 150;
  const medianTerm = calculateMedian(rawValidTerms) || 360;
  const medianAge = calculateMedian(rawValidAges) || 38;
  const medianDebt = calculateMedian(rawValidDebts) || 600;
  const modeCredit = calculateMode(rawValidCreditHistories) ?? 1;
  const modeDependents = calculateMode(rawValidDependents) ?? 0;
  const modeExistingLoans = calculateMode(rawValidExistingLoans) ?? 0;

  const modeEducation = calculateMode(rawEducations) || 'Graduate';
  const modeMarital = calculateMode(rawMarital) || 'Married';
  const modeEmployment = calculateMode(rawEmployment) || 'Salaried';
  const modeSelfEmployed = calculateMode(rawSelfEmployed) || 'No';
  const modePropertyArea = calculateMode(rawPropertyArea) || 'Semiurban';
  const modePropertyType = calculateMode(rawPropertyType) || 'Single Family';
  const modeLoanPurpose = calculateMode(rawLoanPurposes) || 'Home Purchase';

  // Step 2: Clean, validate, impute, and deduplicate
  const seenSignatures = new Set<string>();
  const cleaned: CleanLoanRecord[] = [];

  for (let idx = 0; idx < rawRecords.length; idx++) {
    const r = rawRecords[idx];

    // Normalize target status
    const targetParsed = parseTargetStatus(r.loan_status);
    if (!targetParsed) {
      // Missing or invalid target, skip record for supervised training
      continue;
    }

    // Numerical conversions with bounds validation and median imputation
    let inc = Number(r.applicant_income);
    if (isNaN(inc) || inc < 0) inc = medianIncome;

    let coinc = Number(r.coapplicant_income);
    if (isNaN(coinc) || coinc < 0) coinc = medianCoIncome;

    let loan = Number(r.loan_amount);
    if (isNaN(loan) || loan <= 0) loan = medianLoan;

    let term = Number(r.loan_term);
    if (isNaN(term) || term <= 0) term = medianTerm;

    let age = Number(r.applicant_age);
    if (isNaN(age) || age < 18 || age > 100) age = medianAge;

    let debt = Number(r.monthly_debt);
    if (isNaN(debt) || debt < 0) debt = medianDebt;

    let ch = Number(r.credit_history);
    if (isNaN(ch) || (ch !== 0 && ch !== 1)) ch = modeCredit;

    let dep = Number(r.dependents);
    if (isNaN(dep) || dep < 0) dep = modeDependents;

    let ex = Number(r.existing_loans);
    if (isNaN(ex) || ex < 0) ex = modeExistingLoans;

    // Categorical normalizations
    const eduRaw = r.education ? String(r.education).trim() : modeEducation;
    const education = eduRaw.toLowerCase().includes('not') ? 'Not Graduate' : 'Graduate';

    const maritalRaw = r.marital_status ? String(r.marital_status).trim() : modeMarital;
    let marital_status = 'Single';
    if (maritalRaw.toLowerCase().startsWith('m')) marital_status = 'Married';
    else if (maritalRaw.toLowerCase().startsWith('d')) marital_status = 'Divorced';

    const empRaw = r.employment_status ? String(r.employment_status).trim() : modeEmployment;
    let employment_status = 'Salaried';
    if (empRaw.toLowerCase().includes('self')) employment_status = 'Self-Employed';
    else if (empRaw.toLowerCase().includes('business')) employment_status = 'Business';
    else if (empRaw.toLowerCase().includes('contract')) employment_status = 'Contract';

    const selfRaw = r.self_employed ? String(r.self_employed).trim().toLowerCase() : modeSelfEmployed.toLowerCase();
    const self_employed = (selfRaw === 'yes' || selfRaw === 'y' || selfRaw === '1') ? 'Yes' : 'No';

    const areaRaw = r.property_area ? String(r.property_area).trim() : modePropertyArea;
    let property_area = 'Semiurban';
    if (areaRaw.toLowerCase().startsWith('u')) property_area = 'Urban';
    else if (areaRaw.toLowerCase().startsWith('r')) property_area = 'Rural';

    const typeRaw = r.property_type ? String(r.property_type).trim() : modePropertyType;
    let property_type = 'Single Family';
    if (typeRaw.toLowerCase().includes('apart')) property_type = 'Apartment';
    else if (typeRaw.toLowerCase().includes('town')) property_type = 'Townhouse';
    else if (typeRaw.toLowerCase().includes('condo')) property_type = 'Condo';

    const purpRaw = r.loan_purpose ? String(r.loan_purpose).trim() : modeLoanPurpose;
    let loan_purpose = 'Home Purchase';
    if (purpRaw.toLowerCase().includes('improv')) loan_purpose = 'Home Improvement';
    else if (purpRaw.toLowerCase().includes('debt') || purpRaw.toLowerCase().includes('consol')) loan_purpose = 'Debt Consolidation';
    else if (purpRaw.toLowerCase().includes('educat')) loan_purpose = 'Education';
    else if (purpRaw.toLowerCase().includes('business')) loan_purpose = 'Business';

    const loan_id = r.loan_id ? String(r.loan_id).trim() : `LP${String(1000 + idx).padStart(6, '0')}`;

    // Deduplication key
    const sig = `${loan_id}_${inc}_${loan}_${age}_${ch}`;
    if (seenSignatures.has(sig)) continue;
    seenSignatures.add(sig);

    cleaned.push({
      loan_id,
      applicant_income: Math.round(inc),
      coapplicant_income: Math.round(coinc),
      loan_amount: Math.round(loan),
      loan_term: Math.round(term),
      credit_history: ch,
      employment_status,
      education,
      marital_status,
      dependents: Math.round(dep),
      self_employed,
      property_area,
      property_type,
      existing_loans: Math.round(ex),
      monthly_debt: Math.round(debt),
      applicant_age: Math.round(age),
      loan_purpose,
      loan_status: targetParsed.status,
      target: targetParsed.numeric
    });
  }

  return cleaned;
}
