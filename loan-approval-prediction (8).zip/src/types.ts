export type LoanStatus = 'Approved' | 'Rejected';

export interface RawLoanRecord {
  loan_id?: string;
  applicant_income?: string | number;
  coapplicant_income?: string | number;
  loan_amount?: string | number;
  loan_term?: string | number;
  credit_history?: string | number;
  employment_status?: string;
  education?: string;
  marital_status?: string;
  dependents?: string | number;
  self_employed?: string;
  property_area?: string;
  property_type?: string;
  existing_loans?: string | number;
  monthly_debt?: string | number;
  applicant_age?: string | number;
  loan_purpose?: string;
  loan_status?: string;
  [key: string]: unknown;
}

export interface CleanLoanRecord {
  loan_id: string;
  applicant_income: number;
  coapplicant_income: number;
  loan_amount: number; // in thousands ($k)
  loan_term: number; // in months
  credit_history: number; // 1 or 0
  employment_status: string;
  education: string;
  marital_status: string;
  dependents: number;
  self_employed: string;
  property_area: string;
  property_type: string;
  existing_loans: number;
  monthly_debt: number;
  applicant_age: number;
  loan_purpose: string;
  loan_status: LoanStatus;
  target: number; // 1 = Approved, 0 = Rejected
}

export interface EngineeredLoanRecord extends CleanLoanRecord {
  total_income: number;
  debt_to_income: number; // monthly_debt / (total_income / 12)
  loan_to_income: number; // (loan_amount * 1000) / total_income
  age_group: '18-25' | '26-35' | '36-45' | '46-55' | '56+';
  income_group: 'Low (<$4k)' | 'Moderate ($4k-$7k)' | 'High ($7k-$12k)' | 'Very High ($12k+)';
  loan_amount_group: 'Small (<$100k)' | 'Medium ($100k-$250k)' | 'Large ($250k-$450k)' | 'Jumbo ($450k+)';
  existing_loans_indicator: number; // 1 if existing_loans > 0 else 0
  credit_history_indicator: number; // 1 or 0
}

export interface FeatureEncodingMap {
  featureNames: string[];
  categoricalIndices: Record<string, string[]>;
  numericMeans: Record<string, number>;
  numericStds: Record<string, number>;
  numericCols: string[];
}

export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  rocAuc: number;
  confusionMatrix: {
    trueNegative: number;
    falsePositive: number;
    falseNegative: number;
    truePositive: number;
    total: number;
  };
}

export interface FeatureImportance {
  feature: string;
  label: string;
  importance: number; // normalized between 0 and 1 or coefficient magnitude
  rawCoefficient?: number;
  direction?: 'positive' | 'negative';
}

export interface ModelEvaluationResult {
  logisticRegression: {
    metrics: ModelMetrics;
    featureImportances: FeatureImportance[];
    testProbabilities: Array<{ actual: number; predicted: number; prob: number }>;
  };
  decisionTree: {
    metrics: ModelMetrics;
    featureImportances: FeatureImportance[];
    testProbabilities: Array<{ actual: number; predicted: number; prob: number }>;
  };
  bestModelName: 'Logistic Regression' | 'Decision Tree';
  splitRatio: {
    trainCount: number;
    testCount: number;
  };
}

export interface LoanApplicantInput {
  applicant_age: number;
  marital_status: string;
  dependents: number;
  education: string;
  employment_status: string;
  self_employed: string;
  applicant_income: number;
  coapplicant_income: number;
  existing_loans: number;
  monthly_debt: number;
  loan_amount: number;
  loan_term: number;
  loan_purpose: string;
  property_type: string;
  property_area: string;
  credit_history: number;
}

export interface PredictionResultData {
  predictedStatus: LoanStatus;
  approvalProbability: number;
  rejectionProbability: number;
  confidence: number;
  modelUsed: 'Logistic Regression' | 'Decision Tree';
  threshold: number;
  interpretation: 'High Approval Probability' | 'Moderate Probability' | 'Low Approval Probability';
  interpretationDescription: string;
  topContributingFactors: Array<{
    name: string;
    impact: 'positive' | 'negative';
    description: string;
  }>;
  inputData: LoanApplicantInput;
  timestamp: string;
}

export interface DatasetStatistics {
  totalApplications: number;
  approvedCount: number;
  rejectedCount: number;
  approvalRate: number;
  avgApplicantIncome: number;
  avgCoapplicantIncome: number;
  avgTotalIncome: number;
  avgLoanAmount: number;
  avgMonthlyDebt: number;
  avgCreditScoreIndicator: number; // fraction with credit_history == 1
  avgAge: number;
  minIncome: number;
  maxIncome: number;
  minLoan: number;
  maxLoan: number;
}

export type ActiveTab = 'dashboard' | 'predictor' | 'analysis' | 'performance';
