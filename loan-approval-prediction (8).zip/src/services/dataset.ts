import Papa from 'papaparse';
import {
  RawLoanRecord,
  EngineeredLoanRecord,
  DatasetStatistics,
} from '../types';
import { cleanAndPreprocessData } from '../ml/preprocessing';
import { engineerAllRecords } from '../ml/featureEngineering';
import { trainModels, TrainedModelSuite } from '../ml/modelTraining';

export interface DatasetPayload {
  rawCount: number;
  records: EngineeredLoanRecord[];
  statistics: DatasetStatistics;
  modelSuite: TrainedModelSuite;
}

export function computeDatasetStatistics(records: EngineeredLoanRecord[]): DatasetStatistics {
  const totalApplications = records.length;
  if (totalApplications === 0) {
    return {
      totalApplications: 0,
      approvedCount: 0,
      rejectedCount: 0,
      approvalRate: 0,
      avgApplicantIncome: 0,
      avgCoapplicantIncome: 0,
      avgTotalIncome: 0,
      avgLoanAmount: 0,
      avgMonthlyDebt: 0,
      avgCreditScoreIndicator: 0,
      avgAge: 0,
      minIncome: 0,
      maxIncome: 0,
      minLoan: 0,
      maxLoan: 0,
    };
  }

  const approvedCount = records.filter(r => r.target === 1).length;
  const rejectedCount = totalApplications - approvedCount;
  const approvalRate = Number(((approvedCount / totalApplications) * 100).toFixed(1));

  const totalAppIncome = records.reduce((s, r) => s + r.applicant_income, 0);
  const totalCoIncome = records.reduce((s, r) => s + r.coapplicant_income, 0);
  const totalCombinedIncome = records.reduce((s, r) => s + r.total_income, 0);
  const totalLoanAmt = records.reduce((s, r) => s + r.loan_amount, 0);
  const totalDebt = records.reduce((s, r) => s + r.monthly_debt, 0);
  const totalCreditGood = records.filter(r => r.credit_history === 1).length;
  const totalAge = records.reduce((s, r) => s + r.applicant_age, 0);

  const incomes = records.map(r => r.applicant_income);
  const loans = records.map(r => r.loan_amount);

  return {
    totalApplications,
    approvedCount,
    rejectedCount,
    approvalRate,
    avgApplicantIncome: Math.round(totalAppIncome / totalApplications),
    avgCoapplicantIncome: Math.round(totalCoIncome / totalApplications),
    avgTotalIncome: Math.round(totalCombinedIncome / totalApplications),
    avgLoanAmount: Math.round(totalLoanAmt / totalApplications),
    avgMonthlyDebt: Math.round(totalDebt / totalApplications),
    avgCreditScoreIndicator: Number(((totalCreditGood / totalApplications) * 100).toFixed(1)),
    avgAge: Number((totalAge / totalApplications).toFixed(1)),
    minIncome: Math.min(...incomes),
    maxIncome: Math.max(...incomes),
    minLoan: Math.min(...loans),
    maxLoan: Math.max(...loans),
  };
}

export async function loadAndProcessDataset(csvUrl = '/data/loan_applications.csv'): Promise<DatasetPayload> {
  const response = await fetch(csvUrl);
  if (!response.ok) {
    throw new Error(`Failed to fetch CSV dataset from ${csvUrl}: HTTP status ${response.status}`);
  }

  const csvText = await response.text();

  return new Promise((resolve, reject) => {
    Papa.parse<RawLoanRecord>(csvText, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: false,
      complete: (results) => {
        try {
          if (!results.data || results.data.length === 0) {
            throw new Error('CSV parsed with 0 rows or empty content');
          }

          // 1. Clean & Preprocess
          const cleaned = cleanAndPreprocessData(results.data);
          if (cleaned.length < 20) {
            throw new Error(`Insufficient clean records for training (${cleaned.length} found). Minimum 20 required.`);
          }

          // 2. Feature Engineering
          const engineered = engineerAllRecords(cleaned);

          // 3. Compute Dataset Statistics
          const statistics = computeDatasetStatistics(engineered);

          // 4. Train Models
          const modelSuite = trainModels(engineered);

          resolve({
            rawCount: results.data.length,
            records: engineered,
            statistics,
            modelSuite,
          });
        } catch (err) {
          reject(err);
        }
      },
      error: (error: Error) => {
        reject(error);
      },
    });
  });
}
