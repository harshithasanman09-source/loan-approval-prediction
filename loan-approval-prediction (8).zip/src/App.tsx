import React, { useState, useEffect, useCallback } from 'react';
import {
  ActiveTab,
  PredictionResultData,
  DatasetStatistics,
  ModelEvaluationResult,
  EngineeredLoanRecord,
} from './types';
import { loadAndProcessDataset, DatasetPayload } from './services/dataset';
import { generateLoanPdfReport } from './utils/reportGenerator';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { LoanPredictor } from './pages/LoanPredictor';
import { LoanAnalysis } from './pages/LoanAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';
import {
  ShieldAlert,
  RefreshCw,
  Loader2,
  CheckCircle,
  AlertCircle,
  Sparkles
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [datasetPayload, setDatasetPayload] = useState<DatasetPayload | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRetraining, setIsRetraining] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [latestPrediction, setLatestPrediction] = useState<PredictionResultData | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const loadData = useCallback(async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const payload = await loadAndProcessDataset('/data/loan_applications.csv');
      setDatasetPayload(payload);
    } catch (err: unknown) {
      console.error('Failed to load or train loan model dataset:', err);
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Unable to initialize historical loan dataset. Please verify the CSV file and refresh.'
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRetrain = async () => {
    if (!datasetPayload) return;
    setIsRetraining(true);
    try {
      // Re-load and retrain with fresh split
      const payload = await loadAndProcessDataset('/data/loan_applications.csv');
      setDatasetPayload(payload);
      showToast('Models retrained and re-evaluated on holdout partition.');
    } catch (err) {
      showToast('Retraining failed. Please retry.', 'error');
    } finally {
      setIsRetraining(false);
    }
  };

  const handleDownloadReport = async () => {
    if (!datasetPayload) return;
    setIsGeneratingReport(true);
    try {
      await generateLoanPdfReport(
        datasetPayload.statistics,
        datasetPayload.modelSuite.evaluation,
        datasetPayload.records,
        latestPrediction
      );
      showToast('PDF Underwriting Report generated and downloaded.');
    } catch (err) {
      console.error('PDF generation error:', err);
      showToast('Unable to generate the report. Please try again.', 'error');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 flex font-sans antialiased">
      {/* Sidebar Component */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={tab => setActiveTab(tab)}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        stats={datasetPayload?.statistics}
        evaluation={datasetPayload?.modelSuite.evaluation}
        onDownloadReport={handleDownloadReport}
        isGeneratingReport={isGeneratingReport}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-72">
        {/* Header */}
        <Header
          activeTab={activeTab}
          onOpenSidebar={() => setSidebarOpen(true)}
          onDownloadReport={handleDownloadReport}
          isGeneratingReport={isGeneratingReport}
          onRetrainModels={handleRetrain}
          isRetraining={isRetraining}
        />

        {/* Dynamic Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
            <div
              className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-lg border text-xs font-semibold ${
                toastMessage.type === 'success'
                  ? 'bg-slate-900 text-white border-slate-700'
                  : 'bg-rose-600 text-white border-rose-500'
              }`}
            >
              {toastMessage.type === 'success' ? (
                <CheckCircle className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-200" />
              )}
              <span>{toastMessage.text}</span>
            </div>
          </div>
        )}

        {/* Page Body */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-7xl w-full mx-auto min-w-0">
          {isLoading ? (
            /* Loading State */
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4 text-center">
              <div className="relative">
                <div className="w-14 h-14 rounded-2xl bg-indigo-600/10 flex items-center justify-center text-indigo-600">
                  <Loader2 className="w-7 h-7 animate-spin" />
                </div>
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  Initializing Browser Machine Learning Pipeline
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Parsing loan application CSV, engineering debt/income ratios, normalizing categorical variables, and training Logistic Regression and Decision Tree models...
                </p>
              </div>
            </div>
          ) : errorMessage ? (
            /* Error State */
            <div className="max-w-md mx-auto my-12 p-6 rounded-2xl bg-white border border-rose-200 shadow-sm text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-900">Data Loading Error</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{errorMessage}</p>
              </div>
              <button
                onClick={loadData}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Loading</span>
              </button>
            </div>
          ) : datasetPayload ? (
            /* Active Tab Content */
            <>
              {activeTab === 'dashboard' && (
                <Dashboard
                  stats={datasetPayload.statistics}
                  evaluation={datasetPayload.modelSuite.evaluation}
                  records={datasetPayload.records}
                  onNavigateToPredictor={() => setActiveTab('predictor')}
                />
              )}

              {activeTab === 'predictor' && (
                <LoanPredictor
                  modelSuite={datasetPayload.modelSuite}
                  evaluation={datasetPayload.modelSuite.evaluation}
                  onPredictionMade={pred => setLatestPrediction(pred)}
                  latestPrediction={latestPrediction}
                />
              )}

              {activeTab === 'analysis' && (
                <LoanAnalysis
                  records={datasetPayload.records}
                  stats={datasetPayload.statistics}
                />
              )}

              {activeTab === 'performance' && (
                <ModelPerformance
                  evaluation={datasetPayload.modelSuite.evaluation}
                />
              )}
            </>
          ) : null}
        </main>
      </div>
    </div>
  );
}
