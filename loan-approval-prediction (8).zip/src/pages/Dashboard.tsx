import React from 'react';
import {
  FileText,
  CheckCircle2,
  XCircle,
  Percent,
  DollarSign,
  Briefcase,
  CreditCard,
  Sparkles,
  ArrowUpRight,
  ShieldCheck,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis,
} from 'recharts';
import { DatasetStatistics, ModelEvaluationResult, EngineeredLoanRecord } from '../types';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import {
  getApprovalDistribution,
  getIncomeDistribution,
  getLoanAmountDistribution,
  getCreditHistoryVsApproval,
  getEducationAnalysis,
  getEmploymentAnalysis,
  getPropertyAreaAnalysis,
  getLoanPurposeAnalysis,
  getIncomeGroupAnalysis,
} from '../utils/loanAnalysis';
import { generateDynamicInsights } from '../utils/insights';

interface DashboardProps {
  stats: DatasetStatistics;
  evaluation: ModelEvaluationResult;
  records: EngineeredLoanRecord[];
  onNavigateToPredictor: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  stats,
  evaluation,
  records,
  onNavigateToPredictor,
}) => {
  const approvalData = getApprovalDistribution(records);
  const incomeDist = getIncomeDistribution(records);
  const loanDist = getLoanAmountDistribution(records);
  const creditVsApproval = getCreditHistoryVsApproval(records);
  const eduVsApproval = getEducationAnalysis(records);
  const empVsApproval = getEmploymentAnalysis(records);
  const propVsApproval = getPropertyAreaAnalysis(records);
  const purposeDist = getLoanPurposeAnalysis(records);
  const incomeGroupData = getIncomeGroupAnalysis(records);

  // Sample records for Loan Amount vs Income Scatter (first 100 for clean visualization)
  const scatterData = records.slice(0, 100).map(r => ({
    income: r.applicant_income,
    loan: r.loan_amount,
    status: r.loan_status,
  }));

  const insights = generateDynamicInsights(stats, evaluation, records);

  return (
    <div className="space-y-6 pb-10">
      {/* Welcome & Quick Action Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            Machine Learning Underwriting Analytics
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Portfolio Health &amp; Approval Intelligence
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            Historical analysis of {stats.totalApplications} loan records. Classification models trained directly in your browser with zero external servers.
          </p>
          <div className="pt-2">
            <button
              onClick={onNavigateToPredictor}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-indigo-500 hover:bg-indigo-600 text-white shadow-md shadow-indigo-500/30 transition-all hover:translate-x-0.5"
            >
              <span>Test New Application</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Primary Statistic Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          id="stat-total-apps"
          title="Total Applications"
          value={stats.totalApplications.toLocaleString()}
          subtitle="Loaded from public CSV"
          icon={FileText}
          variant="indigo"
          badge="100% Processed"
        />
        <StatCard
          id="stat-approval-rate"
          title="Portfolio Approval Rate"
          value={`${stats.approvalRate}%`}
          subtitle={`${stats.approvedCount} approved / ${stats.rejectedCount} rejected`}
          icon={Percent}
          variant={stats.approvalRate >= 65 ? 'success' : 'amber'}
          badge={`${stats.approvedCount} Approved`}
        />
        <StatCard
          id="stat-avg-income"
          title="Avg Applicant Income"
          value={`$${stats.avgApplicantIncome.toLocaleString()}`}
          subtitle={`+$${stats.avgCoapplicantIncome.toLocaleString()} co-applicant avg`}
          icon={DollarSign}
          variant="default"
          badge={`$${stats.avgTotalIncome.toLocaleString()} Total`}
        />
        <StatCard
          id="stat-avg-loan"
          title="Avg Loan Requested"
          value={`$${stats.avgLoanAmount}k`}
          subtitle={`Span: $${stats.minLoan}k – $${stats.maxLoan}k`}
          icon={Briefcase}
          variant="default"
          badge="Collateralized"
        />
      </div>

      {/* Secondary Metric Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium">Satisfactory Credit Rate</span>
            <div className="text-xl font-bold text-slate-900 mt-0.5">
              {stats.avgCreditScoreIndicator}%
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium">Average Monthly Debt</span>
            <div className="text-xl font-bold text-slate-900 mt-0.5">
              ${stats.avgMonthlyDebt.toLocaleString()}/mo
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium">Average Applicant Age</span>
            <div className="text-xl font-bold text-slate-900 mt-0.5">
              {stats.avgAge} Years
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Dynamic Key Insights Panel (PRD Section 36) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Sparkles className="w-5 h-5 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Dynamic Analytical Insights
          </h3>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700">
            Calculated On Load
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {insights.map(item => (
            <div
              key={item.id}
              className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between space-y-2"
            >
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {item.title}
                </span>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {item.text}
                </p>
              </div>
              <div className="pt-2 border-t border-slate-200/60 text-[11px] font-semibold text-indigo-600">
                {item.highlight}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 10 Dashboard Visualizations Grid (PRD Section 37) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Approval vs Rejection Distribution */}
        <ChartCard
          id="chart-approval-dist"
          title="1. Portfolio Approval vs Rejection"
          subtitle="Donut breakdown of total historical loan determinations."
          badge={`${stats.approvalRate}% Approved`}
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={approvalData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {approvalData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 2. Applicant Income Distribution */}
        <ChartCard
          id="chart-income-dist"
          title="2. Applicant Monthly Income Distribution"
          subtitle="Volume of applications distributed by primary income bracket."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={incomeDist} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="bracket" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="approved" name="Approved" fill="#10b981" stackId="a" radius={[0, 0, 0, 0]} />
                <Bar dataKey="rejected" name="Rejected" fill="#ef4444" stackId="a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 3. Loan Amount Distribution */}
        <ChartCard
          id="chart-loan-dist"
          title="3. Loan Amount Requested Distribution"
          subtitle="Volume of requests clustered by financing scale ($k)."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={loanDist} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="bracket" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="approved" name="Approved" fill="#3b82f6" stackId="a" />
                <Bar dataKey="rejected" name="Rejected" fill="#f43f5e" stackId="a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 4. Credit History vs Approval */}
        <ChartCard
          id="chart-credit-approval"
          title="4. Credit History vs Approval Rate"
          subtitle="Empirical comparison between satisfactory and adverse credit profiles."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={creditVsApproval} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis unit="%" tick={{ fontSize: 11, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip
                  formatter={(val: number) => [`${val}%`, 'Approval Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="approvalRate" name="Approval Rate (%)" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 5. Education vs Approval */}
        <ChartCard
          id="chart-edu-approval"
          title="5. Education vs Approval"
          subtitle="Comparing qualification rates between Graduate and Non-Graduate applicants."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={eduVsApproval} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis unit="%" tick={{ fontSize: 11, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip
                  formatter={(val: number) => [`${val}%`, 'Approval Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="approvalRate" name="Approval Rate (%)" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 6. Employment Status vs Approval */}
        <ChartCard
          id="chart-emp-approval"
          title="6. Employment Status vs Approval"
          subtitle="Relative success rates across employment classifications."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={empVsApproval} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis unit="%" tick={{ fontSize: 11, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip
                  formatter={(val: number) => [`${val}%`, 'Approval Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="approvalRate" name="Approval Rate (%)" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 7. Property Area vs Approval */}
        <ChartCard
          id="chart-prop-approval"
          title="7. Property Area vs Approval"
          subtitle="Approval frequency across Urban, Semiurban, and Rural regions."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={propVsApproval} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis unit="%" tick={{ fontSize: 11, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip
                  formatter={(val: number) => [`${val}%`, 'Approval Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="approvalRate" name="Approval Rate (%)" fill="#14b8a6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 8. Loan Purpose Distribution */}
        <ChartCard
          id="chart-purpose-dist"
          title="8. Loan Purpose Distribution"
          subtitle="Application volume clustered by use of loan proceeds."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={purposeDist} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar dataKey="approved" name="Approved" fill="#10b981" stackId="p" />
                <Bar dataKey="rejected" name="Rejected" fill="#f43f5e" stackId="p" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 9. Loan Amount vs Applicant Income */}
        <ChartCard
          id="chart-loan-vs-income"
          title="9. Loan Amount vs Applicant Monthly Income"
          subtitle="Leverage distribution across sample records ($k loan vs $ monthly income)."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, bottom: 10, left: 10 }}>
                <XAxis
                  type="number"
                  dataKey="income"
                  name="Monthly Income"
                  unit="$"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                />
                <YAxis
                  type="number"
                  dataKey="loan"
                  name="Loan Amount"
                  unit="k"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                />
                <ZAxis range={[20, 20]} />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Scatter name="Approved" data={scatterData.filter(d => d.status === 'Approved')} fill="#10b981" />
                <Scatter name="Rejected" data={scatterData.filter(d => d.status === 'Rejected')} fill="#ef4444" />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* 10. Approval Rate by Income Group */}
        <ChartCard
          id="chart-income-group-rate"
          title="10. Approval Rate by Income Bracket"
          subtitle="Performance trend across total household earnings categories."
        >
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={incomeGroupData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis unit="%" tick={{ fontSize: 11, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip
                  formatter={(val: number) => [`${val}%`, 'Approval Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="approvalRate" name="Approval Rate (%)" fill="#4f46e5" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>
    </div>
  );
};
