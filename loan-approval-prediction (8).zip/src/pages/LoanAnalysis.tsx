import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import {
  BarChart3,
  Table as TableIcon,
  CreditCard,
  DollarSign,
  Briefcase,
  GraduationCap,
  Home,
  Users
} from 'lucide-react';
import { EngineeredLoanRecord, DatasetStatistics } from '../types';
import { LoanTable } from '../components/LoanTable';
import { ChartCard } from '../components/ChartCard';
import {
  getCreditHistoryVsApproval,
  getIncomeDistribution,
  getLoanAmountDistribution,
  getEmploymentAnalysis,
  getEducationAnalysis,
  getPropertyAreaAnalysis,
  getLoanPurposeAnalysis,
  getAgeGroupAnalysis,
  getCategoryApproval,
} from '../utils/loanAnalysis';

interface LoanAnalysisProps {
  records: EngineeredLoanRecord[];
  stats: DatasetStatistics;
}

export const LoanAnalysis: React.FC<LoanAnalysisProps> = ({ records, stats }) => {
  const [activeAnalysisTab, setActiveAnalysisTab] = useState<'explorer' | 'charts'>('explorer');

  const creditData = getCreditHistoryVsApproval(records);
  const incomeData = getIncomeDistribution(records);
  const loanAmtData = getLoanAmountDistribution(records);
  const empData = getEmploymentAnalysis(records);
  const eduData = getEducationAnalysis(records);
  const propData = getPropertyAreaAnalysis(records);
  const propTypeData = getCategoryApproval(records, 'property_type');
  const purposeData = getLoanPurposeAnalysis(records);
  const ageData = getAgeGroupAnalysis(records);
  const maritalData = getCategoryApproval(records, 'marital_status');

  return (
    <div className="space-y-6 pb-12">
      {/* Top View Selector Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Portfolio Exploration &amp; Subgroup Analysis
          </h2>
          <p className="text-xs text-slate-500">
            Switch between the searchable historical application table and granular demographic underwriting comparisons.
          </p>
        </div>

        <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200 self-start sm:self-auto">
          <button
            onClick={() => setActiveAnalysisTab('explorer')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeAnalysisTab === 'explorer'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TableIcon className="w-4 h-4 text-indigo-600" />
            <span>Loan Explorer Table</span>
          </button>
          <button
            onClick={() => setActiveAnalysisTab('charts')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeAnalysisTab === 'charts'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-indigo-600" />
            <span>Segment Breakdowns</span>
          </button>
        </div>
      </div>

      {activeAnalysisTab === 'explorer' ? (
        /* Loan Explorer Table Section */
        <div className="space-y-4">
          <LoanTable records={records} />
        </div>
      ) : (
        /* Analytical Breakdowns Section */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Credit History Analysis (PRD Section 22) */}
          <ChartCard
            title="Credit History Discrepancy Analysis"
            subtitle="Approval outcomes across credit bureau verified vs unverified/default groups."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={creditData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#10b981" />
                  <Bar dataKey="rejected" name="Rejected" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Income Analysis (PRD Section 23) */}
          <ChartCard
            title="Monthly Income Ranges & Approval"
            subtitle="Evaluating volume and approval frequency across income tiers."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={incomeData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="bracket" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#6366f1" />
                  <Bar dataKey="rejected" name="Rejected" fill="#f43f5e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Loan Amount Analysis (PRD Section 24) */}
          <ChartCard
            title="Loan Amount Sizing ($k) Distribution"
            subtitle="Financing requests segmented by scale tiers."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={loanAmtData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="bracket" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#0ea5e9" />
                  <Bar dataKey="rejected" name="Rejected" fill="#f97316" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Employment Analysis (PRD Section 25) */}
          <ChartCard
            title="Employment Classification"
            subtitle="Comparing approval ratios across employment arrangements."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={empData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#14b8a6" />
                  <Bar dataKey="rejected" name="Rejected" fill="#f43f5e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Education Analysis (PRD Section 26) */}
          <ChartCard
            title="Education Level Qualification Rate"
            subtitle="Graduate vs Non-Graduate comparative outcomes."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={eduData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#8b5cf6" />
                  <Bar dataKey="rejected" name="Rejected" fill="#fda4af" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Property Area Analysis (PRD Section 27) */}
          <ChartCard
            title="Property Location Geography"
            subtitle="Urban, Semiurban, and Rural zone approval distribution."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={propData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#059669" />
                  <Bar dataKey="rejected" name="Rejected" fill="#dc2626" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Property Type Structure Analysis */}
          <ChartCard
            title="Property Physical Structure Type"
            subtitle="Condo, Townhouse, Single Family, Apartment performance."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={propTypeData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#4f46e5" />
                  <Bar dataKey="rejected" name="Rejected" fill="#fb7185" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Age Group Breakdown */}
          <ChartCard
            title="Applicant Age Brackets"
            subtitle="Performance across generation cohorts."
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ageData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '0.75rem',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="approved" name="Approved" fill="#2563eb" />
                  <Bar dataKey="rejected" name="Rejected" fill="#94a3b8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>
      )}
    </div>
  );
};
