import React, { useState } from 'react';
import {
  Cpu,
  Trophy,
  Sliders,
  Layers,
  Activity,
  CheckCircle2,
  Info
} from 'lucide-react';
import { ModelEvaluationResult } from '../types';
import { ModelMetrics } from '../components/ModelMetrics';
import { ConfusionMatrix } from '../components/ConfusionMatrix';
import { FeatureImportanceChart } from '../components/FeatureImportanceChart';
import { ProbabilityDistributionChart } from '../components/ProbabilityDistributionChart';
import { ThresholdAnalysis } from '../components/ThresholdAnalysis';

interface ModelPerformanceProps {
  evaluation: ModelEvaluationResult;
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({ evaluation }) => {
  const [activeModelForMatrix, setActiveModelForMatrix] = useState<'Logistic Regression' | 'Decision Tree'>(
    evaluation.bestModelName
  );

  const currentMetrics =
    activeModelForMatrix === 'Logistic Regression'
      ? evaluation.logisticRegression.metrics
      : evaluation.decisionTree.metrics;

  const currentProbabilities =
    activeModelForMatrix === 'Logistic Regression'
      ? evaluation.logisticRegression.testProbabilities
      : evaluation.decisionTree.testProbabilities;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Browser Classification Engine Benchmark
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Top: {evaluation.bestModelName}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Holdout evaluation on 20% unseen test partition ({evaluation.splitRatio.testCount} records). Feature standardization &amp; zero target leakage.
          </p>
        </div>

        {/* Matrix & Distribution Target Switcher */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-xs font-medium text-slate-500">Inspecting:</span>
          <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200">
            <button
              onClick={() => setActiveModelForMatrix('Logistic Regression')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                activeModelForMatrix === 'Logistic Regression'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Logistic Regression
            </button>
            <button
              onClick={() => setActiveModelForMatrix('Decision Tree')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                activeModelForMatrix === 'Decision Tree'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Decision Tree
            </button>
          </div>
        </div>
      </div>

      {/* 1. Model Metrics Comparison Table */}
      <ModelMetrics evaluation={evaluation} />

      {/* 2. Confusion Matrix & Probability Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ConfusionMatrix
          metrics={currentMetrics}
          modelName={activeModelForMatrix}
        />
        <ProbabilityDistributionChart
          testProbabilities={currentProbabilities}
          modelName={activeModelForMatrix}
        />
      </div>

      {/* 3. Feature Importance & Influence Ranking */}
      <FeatureImportanceChart
        lrImportances={evaluation.logisticRegression.featureImportances}
        dtImportances={evaluation.decisionTree.featureImportances}
        defaultModel={evaluation.bestModelName}
      />

      {/* 4. Threshold Sensitivity Simulator */}
      <ThresholdAnalysis
        testProbabilities={currentProbabilities}
        modelName={activeModelForMatrix}
      />
    </div>
  );
};
