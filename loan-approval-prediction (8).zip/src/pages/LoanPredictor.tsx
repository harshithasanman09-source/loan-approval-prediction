import React, { useState } from 'react';
import {
  LoanApplicantInput,
  PredictionResultData,
  ModelEvaluationResult,
} from '../types';
import { LoanPredictionForm } from '../components/LoanPredictionForm';
import { PredictionResult } from '../components/PredictionResult';
import { TrainedModelSuite } from '../ml/modelTraining';

interface LoanPredictorProps {
  modelSuite: TrainedModelSuite;
  evaluation: ModelEvaluationResult;
  onPredictionMade: (prediction: PredictionResultData) => void;
  latestPrediction: PredictionResultData | null;
}

export const LoanPredictor: React.FC<LoanPredictorProps> = ({
  modelSuite,
  evaluation,
  onPredictionMade,
  latestPrediction,
}) => {
  const [isPredicting, setIsPredicting] = useState(false);

  const handlePredict = (
    input: LoanApplicantInput,
    modelType: 'Logistic Regression' | 'Decision Tree'
  ) => {
    setIsPredicting(true);
    // Microtask simulation so UI state updates fluidly
    setTimeout(() => {
      try {
        const result = modelSuite.predict(input, modelType, 0.5);
        onPredictionMade(result);
      } finally {
        setIsPredicting(false);
      }
    }, 150);
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Form Column (7 cols on desktop) */}
        <div className="lg:col-span-7">
          <LoanPredictionForm
            onPredict={handlePredict}
            bestModelName={evaluation.bestModelName}
            isPredicting={isPredicting}
          />
        </div>

        {/* Right Result Column (5 cols on desktop) */}
        <div className="lg:col-span-5 sticky top-20">
          <PredictionResult result={latestPrediction} />
        </div>
      </div>
    </div>
  );
};
