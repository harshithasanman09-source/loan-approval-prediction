import { DatasetStatistics, ModelEvaluationResult, EngineeredLoanRecord } from '../types';
import { getCreditHistoryVsApproval, getPropertyAreaAnalysis } from './loanAnalysis';

export interface DynamicInsight {
  id: string;
  category: 'portfolio' | 'credit' | 'model' | 'demographics';
  title: string;
  text: string;
  highlight: string;
}

export function generateDynamicInsights(
  stats: DatasetStatistics,
  evaluation: ModelEvaluationResult,
  records: EngineeredLoanRecord[]
): DynamicInsight[] {
  const insights: DynamicInsight[] = [];

  // 1. Portfolio Overview
  insights.push({
    id: 'portfolio-1',
    category: 'portfolio',
    title: 'Historical Approval Rate',
    text: `The active dataset contains ${stats.totalApplications} validated loan applications with a baseline approval rate of ${stats.approvalRate}%.`,
    highlight: `${stats.approvalRate}% overall approval rate`,
  });

  // 2. Credit History Significance
  const creditStats = getCreditHistoryVsApproval(records);
  const goodCredit = creditStats.find(c => c.category.includes('Satisfactory'));
  const badCredit = creditStats.find(c => c.category.includes('Adverse'));
  if (goodCredit && badCredit) {
    insights.push({
      id: 'credit-1',
      category: 'credit',
      title: 'Credit Score Discrepancy',
      text: `Borrowers with verified satisfactory credit history experienced an approval rate of ${goodCredit.approvalRate}%, compared to only ${badCredit.approvalRate}% for applicants with adverse or missing records.`,
      highlight: `${goodCredit.approvalRate}% vs ${badCredit.approvalRate}% approval divergence`,
    });
  }

  // 3. Model Performance Winner
  const bestModel = evaluation.bestModelName;
  const lrF1 = evaluation.logisticRegression.metrics.f1Score;
  const dtF1 = evaluation.decisionTree.metrics.f1Score;
  const bestF1 = bestModel === 'Logistic Regression' ? lrF1 : dtF1;
  const bestAcc = bestModel === 'Logistic Regression'
    ? evaluation.logisticRegression.metrics.accuracy
    : evaluation.decisionTree.metrics.accuracy;

  insights.push({
    id: 'model-1',
    category: 'model',
    title: 'Top Performing Classifier',
    text: `${bestModel} demonstrated the strongest generalization on the 20% test partition, achieving an F1 score of ${bestF1}% and ${bestAcc}% test accuracy.`,
    highlight: `${bestModel} leading with ${bestF1}% F1`,
  });

  // 4. Financial Capital Leverage
  insights.push({
    id: 'portfolio-2',
    category: 'portfolio',
    title: 'Loan Sizing & Income Benchmark',
    text: `Average requested financing stands at $${stats.avgLoanAmount}k against an average primary applicant monthly income of $${stats.avgApplicantIncome.toLocaleString()}, reflecting prudent portfolio underwriting limits.`,
    highlight: `$${stats.avgLoanAmount}k avg loan / $${stats.avgApplicantIncome.toLocaleString()} income`,
  });

  // 5. Geographic Demographic Performance
  const propertyStats = getPropertyAreaAnalysis(records);
  if (propertyStats.length > 0) {
    const highestArea = propertyStats.reduce((prev, cur) => cur.approvalRate > prev.approvalRate ? cur : prev, propertyStats[0]);
    insights.push({
      id: 'demographics-1',
      category: 'demographics',
      title: 'Geographic Outperformance',
      text: `${highestArea.category} properties logged the highest success frequency at ${highestArea.approvalRate}% across ${highestArea.total} historical submissions.`,
      highlight: `${highestArea.category} leading at ${highestArea.approvalRate}%`,
    });
  }

  return insights;
}
