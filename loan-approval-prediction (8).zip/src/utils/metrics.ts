import { ModelMetrics } from '../types';

export function calculateMetrics(
  actuals: number[],
  predictions: number[],
  probabilities?: number[]
): ModelMetrics {
  let truePositive = 0;
  let trueNegative = 0;
  let falsePositive = 0;
  let falseNegative = 0;

  for (let i = 0; i < actuals.length; i++) {
    const act = actuals[i];
    const pred = predictions[i];

    if (act === 1 && pred === 1) truePositive++;
    else if (act === 0 && pred === 0) trueNegative++;
    else if (act === 0 && pred === 1) falsePositive++;
    else if (act === 1 && pred === 0) falseNegative++;
  }

  const total = actuals.length;
  const accuracy = total > 0 ? (truePositive + trueNegative) / total : 0;
  const precision = (truePositive + falsePositive) > 0 ? truePositive / (truePositive + falsePositive) : 0;
  const recall = (truePositive + falseNegative) > 0 ? truePositive / (truePositive + falseNegative) : 0;
  const f1Score = (precision + recall) > 0 ? (2 * precision * recall) / (precision + recall) : 0;

  let rocAuc = 0.5;
  if (probabilities && probabilities.length === actuals.length) {
    rocAuc = calculateRocAuc(actuals, probabilities);
  }

  return {
    accuracy: Number((accuracy * 100).toFixed(2)),
    precision: Number((precision * 100).toFixed(2)),
    recall: Number((recall * 100).toFixed(2)),
    f1Score: Number((f1Score * 100).toFixed(2)),
    rocAuc: Number(rocAuc.toFixed(3)),
    confusionMatrix: {
      trueNegative,
      falsePositive,
      falseNegative,
      truePositive,
      total,
    },
  };
}

export function calculateRocAuc(actuals: number[], probabilities: number[]): number {
  // Combine into pairs
  const items = actuals.map((actual, i) => ({
    actual,
    prob: probabilities[i],
  }));

  // Sort descending by predicted probability
  items.sort((a, b) => b.prob - a.prob);

  const totalPositives = actuals.filter(a => a === 1).length;
  const totalNegatives = actuals.filter(a => a === 0).length;

  if (totalPositives === 0 || totalNegatives === 0) return 0.5;

  let tp = 0;
  let fp = 0;
  let prevFp = 0;
  let prevTp = 0;
  let auc = 0;

  for (let i = 0; i < items.length; i++) {
    if (items[i].actual === 1) {
      tp++;
    } else {
      fp++;
      // Area under step
      auc += (prevTp + tp) / 2 * (1 / totalPositives) * (1 / totalNegatives);
      prevFp = fp;
      prevTp = tp;
    }
  }

  // Final step to (1,1) if needed
  auc += (prevTp + tp) / 2 * (1 / totalPositives) * ((totalNegatives - prevFp) / totalNegatives);

  // Normalize and bound
  const boundedAuc = Math.max(0.5, Math.min(1.0, auc));
  return Number(boundedAuc.toFixed(4));
}
