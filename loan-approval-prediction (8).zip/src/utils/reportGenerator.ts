import { jsPDF } from 'jspdf';
import {
  DatasetStatistics,
  ModelEvaluationResult,
  PredictionResultData,
  EngineeredLoanRecord
} from '../types';
import { generateDynamicInsights } from './insights';

export async function generateLoanPdfReport(
  stats: DatasetStatistics,
  evaluation: ModelEvaluationResult,
  records: EngineeredLoanRecord[],
  currentPrediction?: PredictionResultData | null
): Promise<void> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let yPos = 20;

  // Helper for text
  const addHeader = (title: string) => {
    if (yPos > 260) {
      doc.addPage();
      yPos = 20;
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(title, 20, yPos);
    yPos += 3;
    doc.setDrawColor(203, 213, 225); // slate-300
    doc.setLineWidth(0.5);
    doc.line(20, yPos, pageWidth - 20, yPos);
    yPos += 8;
  };

  const addSubHeader = (title: string) => {
    if (yPos > 265) {
      doc.addPage();
      yPos = 20;
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(51, 65, 85); // slate-700
    doc.text(title, 20, yPos);
    yPos += 6;
  };

  const addText = (text: string, indent = 20, fontSize = 9.5) => {
    if (yPos > 275) {
      doc.addPage();
      yPos = 20;
    }
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(fontSize);
    doc.setTextColor(71, 85, 105); // slate-600
    const lines = doc.splitTextToSize(text, pageWidth - indent - 20);
    doc.text(lines, indent, yPos);
    yPos += lines.length * 5;
  };

  // 1. Cover / Banner
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(20, yPos, pageWidth - 40, 28, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(255, 255, 255);
  doc.text('Loan Approval Prediction', 28, yPos + 11);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(203, 213, 225);
  doc.text('Machine Learning Analytics & Underwriting Diagnostic Report', 28, yPos + 20);
  doc.setFontSize(8.5);
  doc.text(`Generated: ${new Date().toLocaleString()}`, pageWidth - 75, yPos + 20);
  yPos += 36;

  // 2. Executive Summary & Dataset Statistics
  addHeader('1. Executive Dataset Summary');
  addText(
    `This report details exploratory patterns and supervised classification results derived from ${stats.totalApplications} historical loan applications. The target represents historical loan disposition (Approved vs. Rejected).`
  );
  yPos += 2;

  // Key metrics grid
  doc.setFillColor(248, 250, 252);
  doc.rect(20, yPos, pageWidth - 40, 24, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(30, 41, 59);

  doc.text('Total Applications:', 26, yPos + 8);
  doc.text('Approved:', 75, yPos + 8);
  doc.text('Rejected:', 120, yPos + 8);
  doc.text('Approval Rate:', 160, yPos + 8);

  doc.setFont('helvetica', 'normal');
  doc.text(String(stats.totalApplications), 26, yPos + 17);
  doc.text(`${stats.approvedCount} (${stats.approvalRate}%)`, 75, yPos + 17);
  doc.text(`${stats.rejectedCount} (${(100 - stats.approvalRate).toFixed(1)}%)`, 120, yPos + 17);
  doc.text(`${stats.approvalRate}%`, 160, yPos + 17);
  yPos += 30;

  // 3. Financial & Applicant Benchmarks
  addSubHeader('Applicant & Portfolio Financial Benchmarks');
  const metricsList = [
    `Average Primary Applicant Income: $${stats.avgApplicantIncome.toLocaleString()}/mo`,
    `Average Co-Applicant Income: $${stats.avgCoapplicantIncome.toLocaleString()}/mo`,
    `Average Total Household Income: $${stats.avgTotalIncome.toLocaleString()}/mo`,
    `Average Requested Financing: $${stats.avgLoanAmount.toLocaleString()}k ($${(stats.avgLoanAmount * 1000).toLocaleString()})`,
    `Average Monthly Debt Service: $${stats.avgMonthlyDebt.toLocaleString()}/mo`,
    `Favorable Credit History Indicator: ${stats.avgCreditScoreIndicator}% of applicant pool`,
    `Average Applicant Age: ${stats.avgAge} years (Span: 21 to 65)`,
  ];
  metricsList.forEach(m => addText(`• ${m}`, 25));
  yPos += 6;

  // 4. Model Performance Comparison
  addHeader('2. Browser-Trained Machine Learning Evaluation');
  addText(
    `Supervised binary classification was performed in the browser using an 80/20 stratified split (${evaluation.splitRatio.trainCount} training samples, ${evaluation.splitRatio.testCount} holdout validation samples). Target leakage was strictly prevented.`
  );
  yPos += 2;

  // Table header
  doc.setFillColor(241, 245, 249);
  doc.rect(20, yPos, pageWidth - 40, 7, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(30, 41, 59);
  doc.text('Model Algorithm', 24, yPos + 5);
  doc.text('Accuracy', 75, yPos + 5);
  doc.text('Precision', 105, yPos + 5);
  doc.text('Recall', 135, yPos + 5);
  doc.text('F1 Score', 160, yPos + 5);
  doc.text('ROC-AUC', 182, yPos + 5);
  yPos += 8;

  // Logistic row
  const lr = evaluation.logisticRegression.metrics;
  doc.setFont('helvetica', 'normal');
  doc.text('Logistic Regression (L2)', 24, yPos + 4);
  doc.text(`${lr.accuracy}%`, 75, yPos + 4);
  doc.text(`${lr.precision}%`, 105, yPos + 4);
  doc.text(`${lr.recall}%`, 135, yPos + 4);
  doc.text(`${lr.f1Score}%`, 160, yPos + 4);
  doc.text(`${lr.rocAuc}`, 182, yPos + 4);
  yPos += 7;

  // Decision Tree row
  const dt = evaluation.decisionTree.metrics;
  doc.text('Decision Tree (CART)', 24, yPos + 4);
  doc.text(`${dt.accuracy}%`, 75, yPos + 4);
  doc.text(`${dt.precision}%`, 105, yPos + 4);
  doc.text(`${dt.recall}%`, 135, yPos + 4);
  doc.text(`${dt.f1Score}%`, 160, yPos + 4);
  doc.text(`${dt.rocAuc}`, 182, yPos + 4);
  yPos += 10;

  addText(`Selected Superior Architecture: ${evaluation.bestModelName} (Evaluated on harmonic F1 and test accuracy)`);
  yPos += 4;

  // Confusion matrix summary
  const cm = (evaluation.bestModelName === 'Logistic Regression' ? lr : dt).confusionMatrix;
  addSubHeader(`Holdout Confusion Matrix (${evaluation.bestModelName})`);
  addText(`• True Negatives (Correctly rejected): ${cm.trueNegative}`);
  addText(`• False Positives (Incorrectly approved): ${cm.falsePositive}`);
  addText(`• False Negatives (Incorrectly rejected): ${cm.falseNegative}`);
  addText(`• True Positives (Correctly approved): ${cm.truePositive}`);
  yPos += 6;

  // Feature Importance
  addSubHeader('Primary Predictive Drivers (Top Feature Importance)');
  const topFeatures = (evaluation.bestModelName === 'Logistic Regression'
    ? evaluation.logisticRegression.featureImportances
    : evaluation.decisionTree.featureImportances).slice(0, 6);

  topFeatures.forEach((f, idx) => {
    addText(`${idx + 1}. ${f.label} — Relative Importance: ${(f.importance * 100).toFixed(1)}%`);
  });
  yPos += 6;

  // 5. Prediction Case if available
  if (currentPrediction) {
    if (yPos > 220) {
      doc.addPage();
      yPos = 20;
    }
    addHeader('3. Evaluated Loan Application Prediction');
    addText(
      `An interactive prediction was evaluated on ${new Date(currentPrediction.timestamp).toLocaleString()} using the ${currentPrediction.modelUsed} model.`
    );
    yPos += 2;

    doc.setFillColor(currentPrediction.predictedStatus === 'Approved' ? 240 : 254, 253, 244);
    doc.setDrawColor(currentPrediction.predictedStatus === 'Approved' ? 16 : 225, 185, 129);
    doc.rect(20, yPos, pageWidth - 40, 26, 'DF');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(currentPrediction.predictedStatus === 'Approved' ? 22 : 185, 101, 40);
    doc.text(`Outcome: Likely ${currentPrediction.predictedStatus}`, 26, yPos + 8);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(30, 41, 59);
    doc.text(
      `Approval Probability: ${currentPrediction.approvalProbability}%   |   Rejection Probability: ${currentPrediction.rejectionProbability}%   |   Confidence: ${currentPrediction.confidence}%`,
      26,
      yPos + 16
    );
    doc.text(`Interpretation: ${currentPrediction.interpretation}`, 26, yPos + 22);
    yPos += 32;

    const inp = currentPrediction.inputData;
    addSubHeader('Evaluated Applicant Profile');
    addText(`• Applicant Age: ${inp.applicant_age} | Marital Status: ${inp.marital_status} | Dependents: ${inp.dependents}`);
    addText(`• Education: ${inp.education} | Employment: ${inp.employment_status} | Self Employed: ${inp.self_employed}`);
    addText(`• Income: $${inp.applicant_income.toLocaleString()} | Co-applicant: $${inp.coapplicant_income.toLocaleString()} | Total: $${(inp.applicant_income + inp.coapplicant_income).toLocaleString()}`);
    addText(`• Loan Requested: $${inp.loan_amount}k | Term: ${inp.loan_term} months | Purpose: ${inp.loan_purpose}`);
    addText(`• Property: ${inp.property_type} in ${inp.property_area} Area`);
    addText(`• Credit History: ${inp.credit_history === 1 ? 'Satisfactory (1.0)' : 'Adverse (0.0)'} | Monthly Debt: $${inp.monthly_debt}`);
    yPos += 6;
  }

  // 6. Dynamic Insights
  if (yPos > 230) {
    doc.addPage();
    yPos = 20;
  }
  addHeader('4. Dynamic Portfolio Insights');
  const insights = generateDynamicInsights(stats, evaluation, records);
  insights.forEach(item => {
    addSubHeader(item.title);
    addText(item.text, 25);
    yPos += 2;
  });

  // Footer / Disclaimer
  if (yPos > 260) {
    doc.addPage();
    yPos = 20;
  }
  yPos += 4;
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184); // slate-400
  const disclaimer =
    'Responsible Use Notice: This machine-learning report is generated strictly in-browser for analytical and educational purposes. It does not constitute a guaranteed lending decision, underwriting commitment, or regulated financial advice.';
  const discLines = doc.splitTextToSize(disclaimer, pageWidth - 40);
  doc.text(discLines, 20, yPos);

  // Trigger download
  doc.save('loan-approval-prediction-report.pdf');
}
