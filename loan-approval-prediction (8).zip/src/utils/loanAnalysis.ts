import { EngineeredLoanRecord } from '../types';

export interface CategoryApprovalStat {
  category: string;
  total: number;
  approved: number;
  rejected: number;
  approvalRate: number; // percentage
}

export function getApprovalDistribution(records: EngineeredLoanRecord[]) {
  const approved = records.filter(r => r.target === 1).length;
  const rejected = records.length - approved;
  return [
    { name: 'Approved', value: approved, color: '#10b981' },
    { name: 'Rejected', value: rejected, color: '#ef4444' },
  ];
}

export function getIncomeDistribution(records: EngineeredLoanRecord[]) {
  const bins = [
    { label: '<$3k', min: 0, max: 3000, count: 0, approved: 0 },
    { label: '$3k-$5k', min: 3000, max: 5000, count: 0, approved: 0 },
    { label: '$5k-$8k', min: 5000, max: 8000, count: 0, approved: 0 },
    { label: '$8k-$12k', min: 8000, max: 12000, count: 0, approved: 0 },
    { label: '$12k+', min: 12000, max: Infinity, count: 0, approved: 0 },
  ];

  records.forEach(r => {
    const inc = r.applicant_income;
    for (const b of bins) {
      if (inc >= b.min && inc < b.max) {
        b.count++;
        if (r.target === 1) b.approved++;
        break;
      }
    }
  });

  return bins.map(b => ({
    bracket: b.label,
    applications: b.count,
    approved: b.approved,
    rejected: b.count - b.approved,
    approvalRate: b.count > 0 ? Number(((b.approved / b.count) * 100).toFixed(1)) : 0,
  }));
}

export function getLoanAmountDistribution(records: EngineeredLoanRecord[]) {
  const bins = [
    { label: '<$100k', min: 0, max: 100, count: 0, approved: 0 },
    { label: '$100k-$175k', min: 100, max: 175, count: 0, approved: 0 },
    { label: '$175k-$250k', min: 175, max: 250, count: 0, approved: 0 },
    { label: '$250k-$375k', min: 250, max: 375, count: 0, approved: 0 },
    { label: '$375k+', min: 375, max: Infinity, count: 0, approved: 0 },
  ];

  records.forEach(r => {
    const amt = r.loan_amount;
    for (const b of bins) {
      if (amt >= b.min && amt < b.max) {
        b.count++;
        if (r.target === 1) b.approved++;
        break;
      }
    }
  });

  return bins.map(b => ({
    bracket: b.label,
    applications: b.count,
    approved: b.approved,
    rejected: b.count - b.approved,
    approvalRate: b.count > 0 ? Number(((b.approved / b.count) * 100).toFixed(1)) : 0,
  }));
}

export function getCreditHistoryVsApproval(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  const goodCredit = records.filter(r => r.credit_history === 1);
  const badCredit = records.filter(r => r.credit_history === 0);

  const statsFor = (arr: EngineeredLoanRecord[], label: string): CategoryApprovalStat => {
    const total = arr.length;
    const approved = arr.filter(r => r.target === 1).length;
    return {
      category: label,
      total,
      approved,
      rejected: total - approved,
      approvalRate: total > 0 ? Number(((approved / total) * 100).toFixed(1)) : 0,
    };
  };

  return [
    statsFor(goodCredit, 'Satisfactory (1.0)'),
    statsFor(badCredit, 'Adverse / No History (0.0)'),
  ];
}

export function getCategoryApproval(
  records: EngineeredLoanRecord[],
  key: keyof EngineeredLoanRecord
): CategoryApprovalStat[] {
  const map = new Map<string, { total: number; approved: number }>();

  records.forEach(r => {
    const val = String(r[key] ?? 'Unknown');
    const curr = map.get(val) || { total: 0, approved: 0 };
    curr.total++;
    if (r.target === 1) curr.approved++;
    map.set(val, curr);
  });

  const result: CategoryApprovalStat[] = [];
  map.forEach((value, category) => {
    result.push({
      category,
      total: value.total,
      approved: value.approved,
      rejected: value.total - value.approved,
      approvalRate: value.total > 0 ? Number(((value.approved / value.total) * 100).toFixed(1)) : 0,
    });
  });

  return result.sort((a, b) => b.total - a.total);
}

export function getIncomeGroupAnalysis(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  return getCategoryApproval(records, 'income_group');
}

export function getLoanPurposeAnalysis(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  return getCategoryApproval(records, 'loan_purpose');
}

export function getPropertyAreaAnalysis(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  return getCategoryApproval(records, 'property_area');
}

export function getEducationAnalysis(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  return getCategoryApproval(records, 'education');
}

export function getEmploymentAnalysis(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  return getCategoryApproval(records, 'employment_status');
}

export function getAgeGroupAnalysis(records: EngineeredLoanRecord[]): CategoryApprovalStat[] {
  return getCategoryApproval(records, 'age_group');
}
