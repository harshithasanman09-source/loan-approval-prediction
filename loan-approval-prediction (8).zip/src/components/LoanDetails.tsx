import React from 'react';
import { X, CheckCircle, XCircle, User, DollarSign, Building, ShieldCheck, CreditCard } from 'lucide-react';
import { EngineeredLoanRecord } from '../types';

interface LoanDetailsProps {
  record: EngineeredLoanRecord | null;
  onClose: () => void;
}

export const LoanDetails: React.FC<LoanDetailsProps> = ({ record, onClose }) => {
  if (!record) return null;

  const isApproved = record.target === 1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white ${
                isApproved ? 'bg-emerald-600' : 'bg-rose-600'
              }`}
            >
              {isApproved ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  Loan Application #{record.loan_id}
                </h3>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    isApproved ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {record.loan_status}
                </span>
              </div>
              <p className="text-xs text-slate-500">Historical Application Dossier</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Key Financial Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
              <span className="text-[11px] font-medium text-slate-500">Total Income</span>
              <div className="text-base font-bold text-slate-900 mt-0.5">
                ${record.total_income.toLocaleString()}
              </div>
              <span className="text-[10px] text-slate-400">Monthly household</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
              <span className="text-[11px] font-medium text-slate-500">Loan Amount</span>
              <div className="text-base font-bold text-slate-900 mt-0.5">
                ${record.loan_amount}k
              </div>
              <span className="text-[10px] text-slate-400">Term: {record.loan_term} mos</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
              <span className="text-[11px] font-medium text-slate-500">Debt-to-Income</span>
              <div
                className={`text-base font-bold mt-0.5 ${
                  record.debt_to_income > 0.45 ? 'text-rose-600' : 'text-emerald-600'
                }`}
              >
                {(record.debt_to_income * 100).toFixed(1)}%
              </div>
              <span className="text-[10px] text-slate-400">Monthly obligation</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
              <span className="text-[11px] font-medium text-slate-500">Credit Bureau</span>
              <div
                className={`text-base font-bold mt-0.5 ${
                  record.credit_history === 1 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {record.credit_history === 1 ? 'Satisfactory' : 'Adverse'}
              </div>
              <span className="text-[10px] text-slate-400">Code: {record.credit_history}.0</span>
            </div>
          </div>

          {/* Demographic Information */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-1.5">
              <User className="w-4 h-4 text-indigo-600" />
              Applicant Information
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-3 gap-x-4 text-xs">
              <div>
                <span className="text-slate-400 block">Age</span>
                <span className="font-semibold text-slate-900">{record.applicant_age} years ({record.age_group})</span>
              </div>
              <div>
                <span className="text-slate-400 block">Education</span>
                <span className="font-semibold text-slate-900">{record.education}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Marital Status</span>
                <span className="font-semibold text-slate-900">{record.marital_status}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Dependents</span>
                <span className="font-semibold text-slate-900">{record.dependents}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Employment Status</span>
                <span className="font-semibold text-slate-900">{record.employment_status}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Self Employed</span>
                <span className="font-semibold text-slate-900">{record.self_employed}</span>
              </div>
            </div>
          </div>

          {/* Detailed Financials */}
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              Income & Debt Breakdown
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-3 gap-x-4 text-xs">
              <div>
                <span className="text-slate-400 block">Primary Applicant Income</span>
                <span className="font-semibold text-slate-900">${record.applicant_income.toLocaleString()}/mo</span>
              </div>
              <div>
                <span className="text-slate-400 block">Co-Applicant Income</span>
                <span className="font-semibold text-slate-900">${record.coapplicant_income.toLocaleString()}/mo</span>
              </div>
              <div>
                <span className="text-slate-400 block">Monthly Debt Service</span>
                <span className="font-semibold text-slate-900">${record.monthly_debt.toLocaleString()}/mo</span>
              </div>
              <div>
                <span className="text-slate-400 block">Existing Active Loans</span>
                <span className="font-semibold text-slate-900">{record.existing_loans} concurrent</span>
              </div>
              <div>
                <span className="text-slate-400 block">Loan-to-Income (LTI)</span>
                <span className="font-semibold text-slate-900">{record.loan_to_income}x annual</span>
              </div>
              <div>
                <span className="text-slate-400 block">Income Bracket</span>
                <span className="font-semibold text-slate-900">{record.income_group}</span>
              </div>
            </div>
          </div>

          {/* Property & Loan Details */}
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-1.5">
              <Building className="w-4 h-4 text-sky-600" />
              Collateral & Loan Terms
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-3 gap-x-4 text-xs">
              <div>
                <span className="text-slate-400 block">Loan Purpose</span>
                <span className="font-semibold text-slate-900">{record.loan_purpose}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Property Type</span>
                <span className="font-semibold text-slate-900">{record.property_type}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Property Area</span>
                <span className="font-semibold text-slate-900">{record.property_area}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Loan Amount Bracket</span>
                <span className="font-semibold text-slate-900">{record.loan_amount_group}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Total Requested</span>
                <span className="font-semibold text-slate-900">${(record.loan_amount * 1000).toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Term Length</span>
                <span className="font-semibold text-slate-900">{record.loan_term} Months ({Math.round(record.loan_term / 12)} Yrs)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-900 text-white transition-colors"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
