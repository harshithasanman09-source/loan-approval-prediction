import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { TrendingUp, TrendingDown, Layers } from 'lucide-react';
import { FeatureImportance } from '../types';

interface FeatureImportanceChartProps {
  lrImportances: FeatureImportance[];
  dtImportances: FeatureImportance[];
  defaultModel?: 'Logistic Regression' | 'Decision Tree';
}

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({
  lrImportances,
  dtImportances,
  defaultModel = 'Logistic Regression',
}) => {
  const [modelType, setModelType] = useState<'Logistic Regression' | 'Decision Tree'>(defaultModel);

  const rawList = modelType === 'Logistic Regression' ? lrImportances : dtImportances;
  // Take top 10 features for readable chart
  const topFeatures = rawList.slice(0, 10).map(f => ({
    name: f.label,
    importance: Number((f.importance * 100).toFixed(1)),
    direction: f.direction || 'positive',
    raw: f.rawCoefficient,
  })).reverse(); // reverse for clean vertical stack in horizontal BarChart

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            Feature Influence & Importance Ranking
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {modelType === 'Logistic Regression'
              ? 'Normalized weight magnitudes from gradient descent optimization.'
              : 'Gini impurity reduction across all tree branch decision splits.'}
          </p>
        </div>

        {/* Model Switcher */}
        <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setModelType('Logistic Regression')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              modelType === 'Logistic Regression'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Logistic Weights
          </button>
          <button
            type="button"
            onClick={() => setModelType('Decision Tree')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              modelType === 'Decision Tree'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Decision Tree Gini
          </button>
        </div>
      </div>

      {/* Horizontal Bar Chart */}
      <div className="h-72 w-full min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            layout="vertical"
            data={topFeatures}
            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          >
            <XAxis
              type="number"
              domain={[0, 100]}
              tick={{ fontSize: 11, fill: '#64748b' }}
              tickFormatter={(v) => `${v}%`}
            />
            <YAxis
              type="category"
              dataKey="name"
              width={140}
              tick={{ fontSize: 11, fill: '#334155' }}
            />
            <Tooltip
              formatter={(val: number) => [`${val}% relative influence`, 'Importance']}
              contentStyle={{
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderRadius: '0.75rem',
                fontSize: '12px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
              }}
            />
            <Bar dataKey="importance" radius={[0, 6, 6, 0]}>
              {topFeatures.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={
                    modelType === 'Logistic Regression'
                      ? entry.direction === 'positive'
                        ? '#6366f1' // indigo
                        : '#f43f5e' // rose
                      : '#0ea5e9' // sky
                  }
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Top 6 Ranked Summary Cards */}
      <div className="pt-2">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2.5">
          Top Driver Summary
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {rawList.slice(0, 6).map((item, idx) => (
            <div
              key={item.feature}
              className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-2"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 font-bold text-[10px] flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {item.label}
                  </div>
                  {item.rawCoefficient !== undefined && (
                    <div className="text-[10px] text-slate-500 flex items-center gap-1">
                      {item.direction === 'positive' ? (
                        <TrendingUp className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-rose-600" />
                      )}
                      Coeff: {item.rawCoefficient > 0 ? `+${item.rawCoefficient}` : item.rawCoefficient}
                    </div>
                  )}
                </div>
              </div>
              <span className="text-xs font-bold text-slate-900 shrink-0">
                {(item.importance * 100).toFixed(1)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
