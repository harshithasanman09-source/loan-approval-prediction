import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

interface ProbabilityDistributionChartProps {
  testProbabilities: Array<{ actual: number; predicted: number; prob: number }>;
  modelName: string;
}

export const ProbabilityDistributionChart: React.FC<ProbabilityDistributionChartProps> = ({
  testProbabilities,
  modelName,
}) => {
  // Group test probabilities into 10 deciles: [0.0-0.1), [0.1-0.2), ..., [0.9-1.0]
  const deciles = Array.from({ length: 10 }, (_, i) => ({
    range: `${(i * 10)}%-${((i + 1) * 10)}%`,
    min: i * 0.1,
    max: (i + 1) * 0.1,
    actualApproved: 0,
    actualRejected: 0,
  }));

  testProbabilities.forEach(item => {
    const p = Math.min(0.999, Math.max(0, item.prob));
    const idx = Math.min(9, Math.floor(p * 10));
    if (item.actual === 1) {
      deciles[idx].actualApproved++;
    } else {
      deciles[idx].actualRejected++;
    }
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-4">
      <div>
        <h3 className="text-base font-bold text-slate-900 tracking-tight">
          Test Probability Distribution ({modelName})
        </h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Distribution of predicted approval probabilities across actual historical outcomes, illustrating model class separation.
        </p>
      </div>

      <div className="h-64 w-full min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={deciles} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <XAxis dataKey="range" tick={{ fontSize: 10, fill: '#64748b' }} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderRadius: '0.75rem',
                fontSize: '12px',
              }}
            />
            <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
            <Bar dataKey="actualApproved" name="Actual Approved" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="actualRejected" name="Actual Rejected" fill="#ef4444" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
        <span>0.0 (High Risk / Reject)</span>
        <span>Decision Boundary (0.50)</span>
        <span>1.0 (Prime Credit / Approve)</span>
      </div>
    </div>
  );
};
