import React from 'react';
import { Trophy, CheckCircle2, AlertCircle } from 'lucide-react';
import { ModelEvaluationResult } from '../types';

interface ModelMetricsProps {
  evaluation: ModelEvaluationResult;
}

export const ModelMetrics: React.FC<ModelMetricsProps> = ({ evaluation }) => {
  const lr = evaluation.logisticRegression.metrics;
  const dt = evaluation.decisionTree.metrics;
  const best = evaluation.bestModelName;

  const metricRows = [
    {
      name: 'Accuracy',
      desc: 'Overall fraction of correct classifications (TP + TN) / Total',
      lrVal: `${lr.accuracy}%`,
      dtVal: `${dt.accuracy}%`,
      lrBetter: lr.accuracy >= dt.accuracy,
      dtBetter: dt.accuracy > lr.accuracy,
    },
    {
      name: 'Precision',
      desc: 'Proportion of predicted approvals that were truly viable: TP / (TP + FP)',
      lrVal: `${lr.precision}%`,
      dtVal: `${dt.precision}%`,
      lrBetter: lr.precision >= dt.precision,
      dtBetter: dt.precision > lr.precision,
    },
    {
      name: 'Recall (Sensitivity)',
      desc: 'Proportion of actual creditworthy loans correctly approved: TP / (TP + FN)',
      lrVal: `${lr.recall}%`,
      dtVal: `${dt.recall}%`,
      lrBetter: lr.recall >= dt.recall,
      dtBetter: dt.recall > lr.recall,
    },
    {
      name: 'F1 Score',
      desc: 'Harmonic mean of Precision and Recall: 2*(P*R)/(P+R)',
      lrVal: `${lr.f1Score}%`,
      dtVal: `${dt.f1Score}%`,
      lrBetter: lr.f1Score >= dt.f1Score,
      dtBetter: dt.f1Score > lr.f1Score,
    },
    {
      name: 'ROC-AUC',
      desc: 'Area Under Receiver Operating Characteristic Curve (discrimination capability)',
      lrVal: String(lr.rocAuc),
      dtVal: String(dt.rocAuc),
      lrBetter: lr.rocAuc >= dt.rocAuc,
      dtBetter: dt.rocAuc > lr.rocAuc,
    },
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
      <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Model Comparison Matrix
            </h3>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
              <Trophy className="w-3.5 h-3.5 text-amber-600" />
              Best: {best}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Holdout validation partition: {evaluation.splitRatio.trainCount} training samples / {evaluation.splitRatio.testCount} testing samples (80/20 stratified).
          </p>
        </div>
      </div>

      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-100/60 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
              <th className="px-5 py-3.5">Classification Metric</th>
              <th className="px-5 py-3.5">
                <div className="flex items-center gap-2">
                  <span>Logistic Regression (L2)</span>
                  {best === 'Logistic Regression' && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 font-bold">
                      Winner
                    </span>
                  )}
                </div>
              </th>
              <th className="px-5 py-3.5">
                <div className="flex items-center gap-2">
                  <span>Decision Tree (CART)</span>
                  {best === 'Decision Tree' && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 font-bold">
                      Winner
                    </span>
                  )}
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {metricRows.map(row => (
              <tr key={row.name} className="hover:bg-slate-50/60 transition-colors">
                <td className="px-5 py-3.5">
                  <span className="font-bold text-slate-900 text-xs block">{row.name}</span>
                  <span className="text-[11px] text-slate-500">{row.desc}</span>
                </td>
                <td className="px-5 py-3.5 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-sm font-bold ${
                        row.lrBetter ? 'text-indigo-600 font-extrabold' : 'text-slate-800'
                      }`}
                    >
                      {row.lrVal}
                    </span>
                    {row.lrBetter && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    )}
                  </div>
                </td>
                <td className="px-5 py-3.5 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-sm font-bold ${
                        row.dtBetter ? 'text-indigo-600 font-extrabold' : 'text-slate-800'
                      }`}
                    >
                      {row.dtVal}
                    </span>
                    {row.dtBetter && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
