import React from 'react';
import { ModelMetrics } from '../types';

interface ConfusionMatrixProps {
  metrics: ModelMetrics;
  modelName: string;
}

export const ConfusionMatrix: React.FC<ConfusionMatrixProps> = ({ metrics, modelName }) => {
  const { trueNegative, falsePositive, falseNegative, truePositive, total } = metrics.confusionMatrix;

  const tnPct = total > 0 ? ((trueNegative / total) * 100).toFixed(1) : '0';
  const fpPct = total > 0 ? ((falsePositive / total) * 100).toFixed(1) : '0';
  const fnPct = total > 0 ? ((falseNegative / total) * 100).toFixed(1) : '0';
  const tpPct = total > 0 ? ((truePositive / total) * 100).toFixed(1) : '0';

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Confusion Matrix ({modelName})
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Holdout test set evaluation ({total} total predictions at 0.50 decision threshold).
          </p>
        </div>
      </div>

      {/* Visual 2x2 Grid */}
      <div className="max-w-md mx-auto">
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          {/* Top-left empty corner */}
          <div className="flex items-end justify-center pb-2 font-bold text-slate-400">
            Actual \ Pred
          </div>

          {/* Column headers */}
          <div className="p-2 rounded-lg bg-slate-100 font-bold text-slate-700">
            Pred: Rejected
          </div>
          <div className="p-2 rounded-lg bg-slate-100 font-bold text-slate-700">
            Pred: Approved
          </div>

          {/* Row 1: Actual Rejected */}
          <div className="p-2 rounded-lg bg-slate-100 font-bold text-slate-700 flex items-center justify-center">
            Actual: Rejected
          </div>

          {/* TN Box */}
          <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/70 flex flex-col justify-center">
            <span className="text-xs font-semibold text-emerald-800">True Negative (TN)</span>
            <span className="text-2xl font-black text-emerald-950 my-1">{trueNegative}</span>
            <span className="text-[11px] text-emerald-700 font-medium">{tnPct}% of test set</span>
          </div>

          {/* FP Box */}
          <div className="p-4 rounded-xl border border-rose-300 bg-rose-50/70 flex flex-col justify-center">
            <span className="text-xs font-semibold text-rose-800">False Positive (FP)</span>
            <span className="text-2xl font-black text-rose-950 my-1">{falsePositive}</span>
            <span className="text-[11px] text-rose-700 font-medium">{fpPct}% (Type I Error)</span>
          </div>

          {/* Row 2: Actual Approved */}
          <div className="p-2 rounded-lg bg-slate-100 font-bold text-slate-700 flex items-center justify-center">
            Actual: Approved
          </div>

          {/* FN Box */}
          <div className="p-4 rounded-xl border border-amber-300 bg-amber-50/70 flex flex-col justify-center">
            <span className="text-xs font-semibold text-amber-800">False Negative (FN)</span>
            <span className="text-2xl font-black text-amber-950 my-1">{falseNegative}</span>
            <span className="text-[11px] text-amber-700 font-medium">{fnPct}% (Type II Error)</span>
          </div>

          {/* TP Box */}
          <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/70 flex flex-col justify-center">
            <span className="text-xs font-semibold text-emerald-800">True Positive (TP)</span>
            <span className="text-2xl font-black text-emerald-950 my-1">{truePositive}</span>
            <span className="text-[11px] text-emerald-700 font-medium">{tpPct}% of test set</span>
          </div>
        </div>
      </div>

      {/* Explanatory Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 space-y-1">
          <div className="font-bold text-slate-900 flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            True Positive (TP: {truePositive}) & True Negative (TN: {trueNegative})
          </div>
          <p className="text-slate-600 text-[11px] leading-relaxed">
            Accurate classifications where the model correctly validated creditworthy applicants or filtered out adverse credit profiles.
          </p>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 space-y-1">
          <div className="font-bold text-slate-900 flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
            False Positive (FP: {falsePositive}) & False Negative (FN: {falseNegative})
          </div>
          <p className="text-slate-600 text-[11px] leading-relaxed">
            Errors in classification. False Positives present default credit risk, while False Negatives represent missed lending opportunities.
          </p>
        </div>
      </div>
    </div>
  );
};
