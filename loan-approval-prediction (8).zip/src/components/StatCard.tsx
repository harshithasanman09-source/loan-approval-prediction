import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  id?: string;
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  variant?: 'default' | 'success' | 'danger' | 'indigo' | 'amber';
  badge?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  id,
  title,
  value,
  subtitle,
  icon: Icon,
  variant = 'default',
  badge,
}) => {
  const variantStyles = {
    default: {
      border: 'border-slate-200/80',
      bg: 'bg-white',
      iconBox: 'bg-slate-100 text-slate-700',
    },
    success: {
      border: 'border-emerald-200/70',
      bg: 'bg-emerald-50/30',
      iconBox: 'bg-emerald-100/80 text-emerald-700',
    },
    danger: {
      border: 'border-rose-200/70',
      bg: 'bg-rose-50/30',
      iconBox: 'bg-rose-100/80 text-rose-700',
    },
    indigo: {
      border: 'border-indigo-200/70',
      bg: 'bg-indigo-50/30',
      iconBox: 'bg-indigo-100/80 text-indigo-700',
    },
    amber: {
      border: 'border-amber-200/70',
      bg: 'bg-amber-50/30',
      iconBox: 'bg-amber-100/80 text-amber-700',
    },
  };

  const style = variantStyles[variant];

  return (
    <div
      id={id}
      className={`rounded-2xl p-5 border ${style.border} ${style.bg} shadow-xs transition-all hover:shadow-md flex flex-col justify-between`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <span className="text-xs font-medium text-slate-500 tracking-wide uppercase">
            {title}
          </span>
          <div className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {value}
          </div>
        </div>
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${style.iconBox}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>

      {(subtitle || badge) && (
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          {subtitle && <span className="text-slate-500">{subtitle}</span>}
          {badge && (
            <span className="px-2 py-0.5 rounded-full font-semibold bg-slate-100 text-slate-700">
              {badge}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
