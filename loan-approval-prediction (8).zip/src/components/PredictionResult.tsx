import React from 'react';
import {
  CheckCircle,
  XCircle,
  TrendingUp,
  TrendingDown,
  Info,
  ShieldAlert,
  Percent,
  Cpu,
  Clock
} from 'lucide-react';
import { PredictionResultData } from '../types';

interface PredictionResultProps {
  result: PredictionResultData | null;
}

export const PredictionResult: React.FC<PredictionResultProps> = ({ result }) => {
  if (!result) {
    return (
      <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center flex flex-col items-center justify-center min-h-[340px]">
        <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-500 flex items-center justify-center mb-3">
          <TrendingUp className="w-7 h-7" />
        </div>
        <h3 className="text-base font-semibold text-slate-900">
          Awaiting Application Data
        </h3>
        <p className="text-xs text-slate-500 max-w-sm mt-1 leading-relaxed">
          Fill out the applicant details and click &quot;Predict Loan Approval&quot; to generate real-time classification and risk probabilities.
        </p>
      </div>
    );
  }

  const isApproved = result.predictedStatus === 'Approved';

  return (
    <div
      id="prediction-result-card"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 sm:p-7 space-y-6"
    >
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Automated Machine Learning Assessment
          </span>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Loan Approval Prediction
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
            <Cpu className="w-3.5 h-3.5 text-indigo-500" />
            {result.modelUsed}
          </span>
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {new Date(result.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>

      {/* Main Status Display */}
      <div
        className={`rounded-2xl p-6 border transition-all ${
          isApproved
            ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
            : 'bg-rose-50/60 border-rose-200 text-rose-950'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div
              className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
                isApproved ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
              }`}
            >
              {isApproved ? <CheckCircle className="w-8 h-8" /> : <XCircle className="w-8 h-8" />}
            </div>
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider opacity-75">
                Model Classification Outcome
              </div>
              <div className="text-2xl sm:text-3xl font-black tracking-tight">
                {isApproved ? 'Likely Approved' : 'Likely Rejected'}
              </div>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <div className="text-xs font-medium opacity-75">Model Confidence</div>
            <div className="text-2xl sm:text-3xl font-black">{result.confidence}%</div>
          </div>
        </div>

        {/* Probability Progress Bar */}
        <div className="mt-5 space-y-2">
          <div className="flex justify-between text-xs font-semibold">
            <span className="text-emerald-700 flex items-center gap-1">
              <Percent className="w-3 h-3" /> Approval: {result.approvalProbability}%
            </span>
            <span className="text-rose-700 flex items-center gap-1">
              Rejection: {result.rejectionProbability}%
            </span>
          </div>

          <div className="h-3 w-full bg-slate-200 rounded-full overflow-hidden flex shadow-inner">
            <div
              className="bg-emerald-500 h-full transition-all duration-500 ease-out"
              style={{ width: `${result.approvalProbability}%` }}
            />
            <div
              className="bg-rose-500 h-full transition-all duration-500 ease-out"
              style={{ width: `${result.rejectionProbability}%` }}
            />
          </div>

          <div className="flex justify-between text-[11px] text-slate-500">
            <span>Threshold: {result.threshold} (0.50 default)</span>
            <span>Class Boundary: &gt;= 50%</span>
          </div>
        </div>
      </div>

      {/* Model Interpretation */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-3">
        <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h4 className="text-xs font-bold text-slate-900 tracking-wide">
            {result.interpretation}
          </h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            {result.interpretationDescription}
          </p>
        </div>
      </div>

      {/* Primary Contributing Factors */}
      <div>
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
          Key Contributing Applicant Factors
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {result.topContributingFactors.map((factor, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl border border-slate-200 bg-white flex items-start gap-2.5"
            >
              {factor.impact === 'positive' ? (
                <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                  <TrendingUp className="w-3.5 h-3.5" />
                </div>
              ) : (
                <div className="w-6 h-6 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 mt-0.5">
                  <TrendingDown className="w-3.5 h-3.5" />
                </div>
              )}
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {factor.name}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                  {factor.description}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Responsible Use Disclaimer (PRD Section 50) */}
      <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200/80 flex items-start gap-2.5 text-xs text-amber-900">
        <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <p className="leading-relaxed text-[11px]">
          <strong>Responsible-Use Notice:</strong> This application provides a machine-learning prediction based on patterns learned from historical data. It is intended for educational and analytical purposes and does not represent an actual bank lending decision, loan approval guarantee, or financial advice.
        </p>
      </div>
    </div>
  );
};
