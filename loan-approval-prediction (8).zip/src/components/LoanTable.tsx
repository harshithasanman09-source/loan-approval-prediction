import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  CheckCircle,
  XCircle,
  Download
} from 'lucide-react';
import { EngineeredLoanRecord, LoanStatus } from '../types';
import { LoanDetails } from './LoanDetails';

interface LoanTableProps {
  records: EngineeredLoanRecord[];
}

export const LoanTable: React.FC<LoanTableProps> = ({ records }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [educationFilter, setEducationFilter] = useState<string>('ALL');
  const [employmentFilter, setEmploymentFilter] = useState<string>('ALL');
  const [propertyAreaFilter, setPropertyAreaFilter] = useState<string>('ALL');
  const [purposeFilter, setPurposeFilter] = useState<string>('ALL');

  const [sortField, setSortField] = useState<keyof EngineeredLoanRecord>('loan_id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [selectedRecord, setSelectedRecord] = useState<EngineeredLoanRecord | null>(null);

  // Filtered & Sorted Records
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      // Search
      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const matchesId = r.loan_id.toLowerCase().includes(query);
        const matchesPurp = r.loan_purpose.toLowerCase().includes(query);
        const matchesArea = r.property_area.toLowerCase().includes(query);
        if (!matchesId && !matchesPurp && !matchesArea) return false;
      }

      // Status
      if (statusFilter !== 'ALL' && r.loan_status !== statusFilter) return false;

      // Education
      if (educationFilter !== 'ALL' && r.education !== educationFilter) return false;

      // Employment
      if (employmentFilter !== 'ALL' && r.employment_status !== employmentFilter) return false;

      // Property Area
      if (propertyAreaFilter !== 'ALL' && r.property_area !== propertyAreaFilter) return false;

      // Purpose
      if (purposeFilter !== 'ALL' && r.loan_purpose !== purposeFilter) return false;

      return true;
    }).sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];

      let comparison = 0;
      if (typeof valA === 'number' && typeof valB === 'number') {
        comparison = valA - valB;
      } else {
        comparison = String(valA).localeCompare(String(valB));
      }

      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [
    records,
    searchTerm,
    statusFilter,
    educationFilter,
    employmentFilter,
    propertyAreaFilter,
    purposeFilter,
    sortField,
    sortDirection,
  ]);

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const validCurrentPage = Math.min(currentPage, totalPages);
  const startIndex = (validCurrentPage - 1) * pageSize;
  const pageRecords = filteredRecords.slice(startIndex, startIndex + pageSize);

  const handleSort = (field: keyof EngineeredLoanRecord) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setStatusFilter('ALL');
    setEducationFilter('ALL');
    setEmploymentFilter('ALL');
    setPropertyAreaFilter('ALL');
    setPurposeFilter('ALL');
    setCurrentPage(1);
  };

  const exportFilteredCsv = () => {
    const headers = [
      'Loan ID',
      'Applicant Income',
      'Coapplicant Income',
      'Total Income',
      'Loan Amount ($k)',
      'Loan Term (mo)',
      'Credit History',
      'Employment Status',
      'Education',
      'Property Area',
      'Loan Purpose',
      'Loan Status'
    ].join(',');

    const rows = filteredRecords.map(r =>
      [
        r.loan_id,
        r.applicant_income,
        r.coapplicant_income,
        r.total_income,
        r.loan_amount,
        r.loan_term,
        r.credit_history,
        `"${r.employment_status}"`,
        `"${r.education}"`,
        `"${r.property_area}"`,
        `"${r.loan_purpose}"`,
        r.loan_status
      ].join(',')
    );

    const blob = new Blob([[headers, ...rows].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `loan_applications_filtered_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col min-w-0">
      {/* Search & Filter Header */}
      <div className="p-5 border-b border-slate-100 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search by Loan ID (e.g. LP001010), Purpose, or Area..."
              value={searchTerm}
              onChange={e => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden"
            />
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto">
            <button
              onClick={exportFilteredCsv}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              title="Export visible records to CSV"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Export CSV</span>
            </button>

            {(searchTerm || statusFilter !== 'ALL' || educationFilter !== 'ALL' || employmentFilter !== 'ALL' || propertyAreaFilter !== 'ALL' || purposeFilter !== 'ALL') && (
              <button
                onClick={handleResetFilters}
                className="px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              >
                Reset Filters
              </button>
            )}
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 pt-1">
          {/* Status Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Loan Status
            </label>
            <select
              value={statusFilter}
              onChange={e => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white outline-hidden focus:border-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>

          {/* Education Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Education
            </label>
            <select
              value={educationFilter}
              onChange={e => {
                setEducationFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white outline-hidden focus:border-indigo-500"
            >
              <option value="ALL">All Educations</option>
              <option value="Graduate">Graduate</option>
              <option value="Not Graduate">Not Graduate</option>
            </select>
          </div>

          {/* Employment Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Employment
            </label>
            <select
              value={employmentFilter}
              onChange={e => {
                setEmploymentFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white outline-hidden focus:border-indigo-500"
            >
              <option value="ALL">All Employment</option>
              <option value="Salaried">Salaried</option>
              <option value="Self-Employed">Self-Employed</option>
              <option value="Business">Business</option>
              <option value="Contract">Contract</option>
            </select>
          </div>

          {/* Property Area Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Property Area
            </label>
            <select
              value={propertyAreaFilter}
              onChange={e => {
                setPropertyAreaFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white outline-hidden focus:border-indigo-500"
            >
              <option value="ALL">All Areas</option>
              <option value="Semiurban">Semiurban</option>
              <option value="Urban">Urban</option>
              <option value="Rural">Rural</option>
            </select>
          </div>

          {/* Loan Purpose Filter */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Loan Purpose
            </label>
            <select
              value={purposeFilter}
              onChange={e => {
                setPurposeFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white outline-hidden focus:border-indigo-500"
            >
              <option value="ALL">All Purposes</option>
              <option value="Home Purchase">Home Purchase</option>
              <option value="Home Improvement">Home Improvement</option>
              <option value="Debt Consolidation">Debt Consolidation</option>
              <option value="Education">Education</option>
              <option value="Business">Business</option>
            </select>
          </div>
        </div>
      </div>

      {/* Internal Scrolling Table Container */}
      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200/80 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
              <th
                onClick={() => handleSort('loan_id')}
                className="px-4 py-3 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1.5">
                  <span>Loan ID</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('applicant_income')}
                className="px-4 py-3 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1.5">
                  <span>Income</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('loan_amount')}
                className="px-4 py-3 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1.5">
                  <span>Loan Amount</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                onClick={() => handleSort('credit_history')}
                className="px-4 py-3 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1.5">
                  <span>Credit</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="px-4 py-3 whitespace-nowrap">Employment</th>
              <th className="px-4 py-3 whitespace-nowrap">Education</th>
              <th className="px-4 py-3 whitespace-nowrap">Property Area</th>
              <th
                onClick={() => handleSort('loan_status')}
                className="px-4 py-3 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1.5">
                  <span>Status</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="px-4 py-3 text-right whitespace-nowrap">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {pageRecords.length === 0 ? (
              <tr>
                <td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                  No loan applications found matching the selected search and filter criteria.
                </td>
              </tr>
            ) : (
              pageRecords.map(r => {
                const isApproved = r.target === 1;
                return (
                  <tr
                    key={r.loan_id}
                    className="hover:bg-slate-50/70 transition-colors"
                  >
                    <td className="px-4 py-3 font-mono font-medium text-slate-900 whitespace-nowrap">
                      {r.loan_id}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-semibold text-slate-900">${r.applicant_income.toLocaleString()}</span>
                      {r.coapplicant_income > 0 && (
                        <span className="text-[10px] text-slate-400 block">
                          +${r.coapplicant_income.toLocaleString()} co-app
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-semibold text-slate-900">${r.loan_amount}k</span>
                      <span className="text-[10px] text-slate-400 block">{r.loan_term} mo term</span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          r.credit_history === 1
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                            : 'bg-rose-50 text-rose-700 border border-rose-200/60'
                        }`}
                      >
                        {r.credit_history === 1 ? '1.0 Good' : '0.0 Adverse'}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {r.employment_status}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {r.education}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px]">
                        {r.property_area}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                          isApproved
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {isApproved ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                        {r.loan_status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button
                        onClick={() => setSelectedRecord(r)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <span>Showing</span>
          <select
            value={pageSize}
            onChange={e => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2 py-1 border border-slate-300 rounded-lg bg-white outline-hidden text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span>of {filteredRecords.length} records</span>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={validCurrentPage === 1}
            className="p-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="font-semibold text-slate-700">
            Page {validCurrentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={validCurrentPage >= totalPages}
            className="p-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Selected Record Modal */}
      {selectedRecord && (
        <LoanDetails
          record={selectedRecord}
          onClose={() => setSelectedRecord(null)}
        />
      )}
    </div>
  );
};
