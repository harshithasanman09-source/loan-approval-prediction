import React, { useState } from 'react';
import {
  Calculator,
  RotateCcw,
  Sparkles,
  AlertCircle,
  TrendingUp,
  User,
  DollarSign,
  Building,
  CreditCard,
  Zap
} from 'lucide-react';
import { LoanApplicantInput } from '../types';

interface LoanPredictionFormProps {
  onPredict: (input: LoanApplicantInput, modelType: 'Logistic Regression' | 'Decision Tree') => void;
  bestModelName: 'Logistic Regression' | 'Decision Tree';
  isPredicting?: boolean;
}

const defaultApplicant: LoanApplicantInput = {
  applicant_age: 36,
  marital_status: 'Married',
  dependents: 1,
  education: 'Graduate',
  employment_status: 'Salaried',
  self_employed: 'No',
  applicant_income: 6200,
  coapplicant_income: 2400,
  existing_loans: 1,
  monthly_debt: 750,
  loan_amount: 220,
  loan_term: 360,
  loan_purpose: 'Home Purchase',
  property_type: 'Single Family',
  property_area: 'Semiurban',
  credit_history: 1,
};

const presets: Array<{ name: string; desc: string; data: LoanApplicantInput }> = [
  {
    name: 'Prime Applicant',
    desc: 'Graduate, dual-income, clear credit, low DTI',
    data: {
      applicant_age: 38,
      marital_status: 'Married',
      dependents: 1,
      education: 'Graduate',
      employment_status: 'Salaried',
      self_employed: 'No',
      applicant_income: 7800,
      coapplicant_income: 3200,
      existing_loans: 1,
      monthly_debt: 680,
      loan_amount: 240,
      loan_term: 360,
      loan_purpose: 'Home Purchase',
      property_type: 'Single Family',
      property_area: 'Semiurban',
      credit_history: 1,
    },
  },
  {
    name: 'Borderline Applicant',
    desc: 'Moderate income, single, higher debt multiple',
    data: {
      applicant_age: 28,
      marital_status: 'Single',
      dependents: 0,
      education: 'Graduate',
      employment_status: 'Salaried',
      self_employed: 'No',
      applicant_income: 4100,
      coapplicant_income: 0,
      existing_loans: 2,
      monthly_debt: 1150,
      loan_amount: 190,
      loan_term: 360,
      loan_purpose: 'Home Purchase',
      property_type: 'Condo',
      property_area: 'Urban',
      credit_history: 1,
    },
  },
  {
    name: 'Adverse Credit Case',
    desc: 'High debt obligations and delinquent credit history',
    data: {
      applicant_age: 44,
      marital_status: 'Married',
      dependents: 2,
      education: 'Not Graduate',
      employment_status: 'Self-Employed',
      self_employed: 'Yes',
      applicant_income: 3600,
      coapplicant_income: 800,
      existing_loans: 3,
      monthly_debt: 1450,
      loan_amount: 230,
      loan_term: 240,
      loan_purpose: 'Debt Consolidation',
      property_type: 'Townhouse',
      property_area: 'Rural',
      credit_history: 0,
    },
  },
];

export const LoanPredictionForm: React.FC<LoanPredictionFormProps> = ({
  onPredict,
  bestModelName,
  isPredicting = false,
}) => {
  const [formData, setFormData] = useState<LoanApplicantInput>(defaultApplicant);
  const [selectedModel, setSelectedModel] = useState<'Logistic Regression' | 'Decision Tree'>(bestModelName);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (formData.applicant_age < 18 || formData.applicant_age > 95) {
      errs.applicant_age = 'Age must be between 18 and 95';
    }
    if (formData.applicant_income < 0) {
      errs.applicant_income = 'Income cannot be negative';
    }
    if (formData.coapplicant_income < 0) {
      errs.coapplicant_income = 'Co-applicant income cannot be negative';
    }
    if (formData.loan_amount <= 0) {
      errs.loan_amount = 'Loan amount must be greater than 0';
    }
    if (formData.loan_term <= 0) {
      errs.loan_term = 'Loan term must be positive';
    }
    if (formData.monthly_debt < 0) {
      errs.monthly_debt = 'Monthly debt cannot be negative';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onPredict(formData, selectedModel);
    }
  };

  const handlePresetSelect = (presetData: LoanApplicantInput) => {
    setFormData({ ...presetData });
    setErrors({});
  };

  const totalIncome = formData.applicant_income + formData.coapplicant_income;
  const dti = totalIncome > 0 ? ((formData.monthly_debt / (totalIncome / 12)) * 100).toFixed(1) : '0';
  const lti = totalIncome > 0 ? (((formData.loan_amount * 1000) / totalIncome)).toFixed(1) : '0';

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
      {/* Header & Presets */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Calculator className="w-5 h-5 text-indigo-600" />
            Underwriting Assessment Form
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Provide applicant details to evaluate approval likelihood via mathematical models.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            Sample Profiles:
          </span>
          {presets.map(p => (
            <button
              key={p.name}
              type="button"
              onClick={() => handlePresetSelect(p.data)}
              className="px-2.5 py-1 text-xs font-medium bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 rounded-lg border border-slate-200 transition-colors"
            >
              {p.name}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              setFormData(defaultApplicant);
              setErrors({});
            }}
            title="Reset Form"
            className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-6">
        {/* Section 1: Applicant Demographics */}
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-3 text-slate-700">
            <User className="w-4 h-4 text-indigo-500" />
            1. Applicant Demographics
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label htmlFor="applicant_age" className="block text-xs font-medium text-slate-700 mb-1">
                Applicant Age (Years)
              </label>
              <input
                id="applicant_age"
                type="number"
                min="18"
                max="95"
                value={formData.applicant_age}
                onChange={e => setFormData({ ...formData, applicant_age: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden"
              />
              {errors.applicant_age && <p className="text-xs text-rose-600 mt-1">{errors.applicant_age}</p>}
            </div>

            <div>
              <label htmlFor="marital_status" className="block text-xs font-medium text-slate-700 mb-1">
                Marital Status
              </label>
              <select
                id="marital_status"
                value={formData.marital_status}
                onChange={e => setFormData({ ...formData, marital_status: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="Married">Married</option>
                <option value="Single">Single</option>
                <option value="Divorced">Divorced</option>
              </select>
            </div>

            <div>
              <label htmlFor="dependents" className="block text-xs font-medium text-slate-700 mb-1">
                Number of Dependents
              </label>
              <select
                id="dependents"
                value={formData.dependents}
                onChange={e => setFormData({ ...formData, dependents: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value={0}>0 Dependents</option>
                <option value={1}>1 Dependent</option>
                <option value={2}>2 Dependents</option>
                <option value={3}>3+ Dependents</option>
              </select>
            </div>

            <div>
              <label htmlFor="education" className="block text-xs font-medium text-slate-700 mb-1">
                Education Level
              </label>
              <select
                id="education"
                value={formData.education}
                onChange={e => setFormData({ ...formData, education: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="Graduate">Graduate</option>
                <option value="Not Graduate">Not Graduate</option>
              </select>
            </div>

            <div>
              <label htmlFor="employment_status" className="block text-xs font-medium text-slate-700 mb-1">
                Employment Classification
              </label>
              <select
                id="employment_status"
                value={formData.employment_status}
                onChange={e => setFormData({ ...formData, employment_status: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="Salaried">Salaried Employee</option>
                <option value="Self-Employed">Self-Employed Professional</option>
                <option value="Business">Business Owner</option>
                <option value="Contract">Contract / Freelance</option>
              </select>
            </div>

            <div>
              <label htmlFor="self_employed" className="block text-xs font-medium text-slate-700 mb-1">
                Self-Employed Indicator
              </label>
              <select
                id="self_employed"
                value={formData.self_employed}
                onChange={e => setFormData({ ...formData, self_employed: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="No">No (Standard W2 / Salaried)</option>
                <option value="Yes">Yes (1099 / Independent)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Financial Profile */}
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-3 text-slate-700">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            2. Financial Information & Cashflow
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label htmlFor="applicant_income" className="block text-xs font-medium text-slate-700 mb-1">
                Applicant Monthly Income ($)
              </label>
              <input
                id="applicant_income"
                type="number"
                min="0"
                step="100"
                value={formData.applicant_income}
                onChange={e => setFormData({ ...formData, applicant_income: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden"
              />
              {errors.applicant_income && <p className="text-xs text-rose-600 mt-1">{errors.applicant_income}</p>}
            </div>

            <div>
              <label htmlFor="coapplicant_income" className="block text-xs font-medium text-slate-700 mb-1">
                Co-Applicant Income ($)
              </label>
              <input
                id="coapplicant_income"
                type="number"
                min="0"
                step="100"
                value={formData.coapplicant_income}
                onChange={e => setFormData({ ...formData, coapplicant_income: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden"
              />
            </div>

            <div>
              <label htmlFor="existing_loans" className="block text-xs font-medium text-slate-700 mb-1">
                Existing Active Loans
              </label>
              <select
                id="existing_loans"
                value={formData.existing_loans}
                onChange={e => setFormData({ ...formData, existing_loans: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value={0}>0 (No other loans)</option>
                <option value={1}>1 existing loan</option>
                <option value={2}>2 existing loans</option>
                <option value={3}>3+ existing loans</option>
              </select>
            </div>

            <div>
              <label htmlFor="monthly_debt" className="block text-xs font-medium text-slate-700 mb-1">
                Monthly Debt Service ($)
              </label>
              <input
                id="monthly_debt"
                type="number"
                min="0"
                step="25"
                value={formData.monthly_debt}
                onChange={e => setFormData({ ...formData, monthly_debt: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden"
              />
              {errors.monthly_debt && <p className="text-xs text-rose-600 mt-1">{errors.monthly_debt}</p>}
            </div>
          </div>

          {/* Computed Ratios Banner */}
          <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200/60 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-indigo-500" />
              <span>Calculated Total Income:</span>
              <strong className="text-slate-900">${totalIncome.toLocaleString()}/mo</strong>
            </div>
            <div>
              <span>Debt-to-Income (DTI):</span>{' '}
              <strong className={Number(dti) > 45 ? 'text-rose-600' : 'text-emerald-600'}>
                {dti}%
              </strong>{' '}
              <span className="text-slate-400">(standard &lt; 43%)</span>
            </div>
            <div>
              <span>Loan-to-Income (LTI):</span>{' '}
              <strong className="text-slate-900">{lti}x</strong>
            </div>
          </div>
        </div>

        {/* Section 3: Loan & Property */}
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-3 text-slate-700">
            <Building className="w-4 h-4 text-sky-600" />
            3. Loan Terms & Collateral Property
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label htmlFor="loan_amount" className="block text-xs font-medium text-slate-700 mb-1">
                Loan Amount Requested ($ in Thousands)
              </label>
              <div className="relative">
                <input
                  id="loan_amount"
                  type="number"
                  min="20"
                  max="1200"
                  step="5"
                  value={formData.loan_amount}
                  onChange={e => setFormData({ ...formData, loan_amount: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400 pointer-events-none">
                  = ${(formData.loan_amount * 1000).toLocaleString()}
                </span>
              </div>
              {errors.loan_amount && <p className="text-xs text-rose-600 mt-1">{errors.loan_amount}</p>}
            </div>

            <div>
              <label htmlFor="loan_term" className="block text-xs font-medium text-slate-700 mb-1">
                Loan Duration / Term
              </label>
              <select
                id="loan_term"
                value={formData.loan_term}
                onChange={e => setFormData({ ...formData, loan_term: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value={120}>120 Months (10 Years)</option>
                <option value={180}>180 Months (15 Years)</option>
                <option value={240}>240 Months (20 Years)</option>
                <option value={360}>360 Months (30 Years - Standard)</option>
                <option value={480}>480 Months (40 Years)</option>
              </select>
            </div>

            <div>
              <label htmlFor="loan_purpose" className="block text-xs font-medium text-slate-700 mb-1">
                Loan Purpose
              </label>
              <select
                id="loan_purpose"
                value={formData.loan_purpose}
                onChange={e => setFormData({ ...formData, loan_purpose: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="Home Purchase">Home Purchase</option>
                <option value="Home Improvement">Home Improvement</option>
                <option value="Debt Consolidation">Debt Consolidation</option>
                <option value="Education">Education</option>
                <option value="Business">Business Expansion</option>
              </select>
            </div>

            <div>
              <label htmlFor="property_type" className="block text-xs font-medium text-slate-700 mb-1">
                Property Structure Type
              </label>
              <select
                id="property_type"
                value={formData.property_type}
                onChange={e => setFormData({ ...formData, property_type: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="Single Family">Single Family Residence</option>
                <option value="Apartment">Apartment</option>
                <option value="Townhouse">Townhouse</option>
                <option value="Condo">Condominium</option>
              </select>
            </div>

            <div>
              <label htmlFor="property_area" className="block text-xs font-medium text-slate-700 mb-1">
                Property Geographic Area
              </label>
              <select
                id="property_area"
                value={formData.property_area}
                onChange={e => setFormData({ ...formData, property_area: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-hidden bg-white"
              >
                <option value="Urban">Urban</option>
                <option value="Semiurban">Semiurban (Suburban)</option>
                <option value="Rural">Rural</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 4: Credit History */}
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-3 text-slate-700">
            <CreditCard className="w-4 h-4 text-purple-600" />
            4. Credit History Record
          </h3>
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
            <label className="block text-xs font-medium text-slate-700 mb-2">
              Credit Bureau History Rating
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                  formData.credit_history === 1
                    ? 'bg-indigo-50/60 border-indigo-300 text-slate-900 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="credit_history"
                  checked={formData.credit_history === 1}
                  onChange={() => setFormData({ ...formData, credit_history: 1 })}
                  className="mt-0.5 text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="font-semibold text-xs text-slate-900">
                    Satisfactory Credit History (1.0)
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    No recent defaults, on-time payments on revolving debts.
                  </div>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                  formData.credit_history === 0
                    ? 'bg-rose-50/60 border-rose-300 text-slate-900 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="credit_history"
                  checked={formData.credit_history === 0}
                  onChange={() => setFormData({ ...formData, credit_history: 0 })}
                  className="mt-0.5 text-rose-600 focus:ring-rose-500"
                />
                <div>
                  <div className="font-semibold text-xs text-slate-900">
                    Adverse or Unestablished Credit (0.0)
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Past 90+ day delinquency, default history, or sparse record.
                  </div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Prediction Controls & Submission */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <span className="text-xs font-medium text-slate-600 shrink-0">
              Evaluation Model:
            </span>
            <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200">
              <button
                type="button"
                id="select-lr-model-btn"
                onClick={() => setSelectedModel('Logistic Regression')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  selectedModel === 'Logistic Regression'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Logistic Regression
                {bestModelName === 'Logistic Regression' && (
                  <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[9px] bg-emerald-100 text-emerald-800">
                    Best
                  </span>
                )}
              </button>
              <button
                type="button"
                id="select-dt-model-btn"
                onClick={() => setSelectedModel('Decision Tree')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  selectedModel === 'Decision Tree'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Decision Tree
                {bestModelName === 'Decision Tree' && (
                  <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[9px] bg-emerald-100 text-emerald-800">
                    Best
                  </span>
                )}
              </button>
            </div>
          </div>

          <button
            type="submit"
            id="predict-loan-approval-btn"
            disabled={isPredicting}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-600/20 transition-all hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Sparkles className="w-4 h-4 text-indigo-200" />
            <span>{isPredicting ? 'Evaluating Pattern...' : 'Predict Loan Approval'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
