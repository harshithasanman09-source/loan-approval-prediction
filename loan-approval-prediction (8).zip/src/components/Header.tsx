import React from 'react';
import { Menu, FileDown, Sparkles, RefreshCw } from 'lucide-react';
import { ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenSidebar: () => void;
  onDownloadReport: () => void;
  isGeneratingReport: boolean;
  onRetrainModels?: () => void;
  isRetraining?: boolean;
}

const titles: Record<ActiveTab, { title: string; subtitle: string }> = {
  dashboard: {
    title: 'Loan Portfolio Dashboard',
    subtitle: 'Comprehensive distribution metrics and demographic insights computed dynamically from historical data.',
  },
  predictor: {
    title: 'Loan Approval Predictor',
    subtitle: 'Input applicant financial attributes to generate instant approval probabilities using browser-trained models.',
  },
  analysis: {
    title: 'Historical Loan Analysis',
    subtitle: 'Explore, filter, and inspect individual loan applications across demographic and financial segments.',
  },
  performance: {
    title: 'Model Performance & Evaluation',
    subtitle: 'Compare Logistic Regression and Decision Tree architectures on holdout validation data with confusion matrix.',
  },
};

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenSidebar,
  onDownloadReport,
  isGeneratingReport,
  onRetrainModels,
  isRetraining = false,
}) => {
  const current = titles[activeTab];

  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between transition-all"
    >
      <div className="flex items-center gap-3 min-w-0">
        <button
          id="mobile-menu-toggle-btn"
          onClick={onOpenSidebar}
          className="p-2 -ml-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden focus:outline-hidden"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight truncate">
              {current.title}
            </h1>
            <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
              <Sparkles className="w-3 h-3" />
              Browser ML
            </span>
          </div>
          <p className="text-xs text-slate-500 truncate hidden md:block max-w-xl">
            {current.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2.5 shrink-0">
        {onRetrainModels && (
          <button
            id="retrain-models-btn"
            onClick={onRetrainModels}
            disabled={isRetraining}
            title="Retrain Logistic Regression & Decision Tree models"
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRetraining ? 'animate-spin text-indigo-600' : 'text-slate-600'}`} />
            <span className="hidden sm:inline">{isRetraining ? 'Training...' : 'Retrain'}</span>
          </button>
        )}

        <button
          id="header-download-report-btn"
          onClick={onDownloadReport}
          disabled={isGeneratingReport}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <FileDown className="w-4 h-4 text-indigo-300" />
          <span>{isGeneratingReport ? 'Exporting PDF...' : 'Download PDF Report'}</span>
        </button>
      </div>
    </header>
  );
};
