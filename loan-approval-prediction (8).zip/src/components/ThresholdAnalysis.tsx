import React, { useState, useMemo } from 'react';
import { Sliders, AlertCircle, Info, Activity } from 'lucide-react';
import { calculateMetrics } from '../utils/metrics';

interface ThresholdAnalysisProps {
  testProbabilities: Array<{ actual: number; predicted: number; prob: number }>;
  modelName: string;
}

export const ThresholdAnalysis: React.FC<ThresholdAnalysisProps> = ({
  testProbabilities,
  modelName,
}) => {
  const [threshold, setThreshold] = useState<number>(0.5);

  const analysis = useMemo(() => {
    const actuals = testProbabilities.map(t => t.actual);
    const probabilities = testProbabilities.map(t => t.prob);
    const dynamicPreds = testProbabilities.map(t => (t.prob >= threshold ? 1 : 0));

    const metrics = calculateMetrics(actuals, dynamicPreds, probabilities);
    const approvedCount = dynamicPreds.filter(p => p === 1).length;
    const rejectedCount = dynamicPreds.filter(p => p === 0).length;

    return {
      metrics,
      approvedCount,
      rejectedCount,
      total: testProbabilities.length,
    };
  }, [testProbabilities, threshold]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Classification Threshold Sensitivity Simulator
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Test how modifying the binary decision cutoff impacts underwriting volume, precision, and portfolio default risk.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] uppercase font-bold text-slate-400">Current Threshold</span>
          <div className="text-xl font-black text-indigo-600 font-mono">
            {threshold.toFixed(2)}
          </div>
        </div>
      </div>

      {/* Slider Control */}
      <div className="space-y-2 p-4 rounded-xl bg-slate-50 border border-slate-200/70">
        <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
          <span>Aggressive Growth (0.20 Cutoff)</span>
          <span className="font-bold text-indigo-700 text-sm">Cutoff: {threshold.toFixed(2)}</span>
          <span>Conservative Underwriting (0.80 Cutoff)</span>
        </div>
        <input
          type="range"
          min="0.10"
          max="0.90"
          step="0.05"
          value={threshold}
          onChange={e => setThreshold(Number(e.target.value))}
          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
        />
        <div className="flex justify-between text-[10px] text-slate-400">
          <span>Higher Approval Volume &bull; Higher Default Exposure</span>
          <span>Default: 0.50</span>
          <span>Lower Approval Volume &bull; Maximum Quality</span>
        </div>
      </div>

      {/* Real-time Dynamic Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
          <span className="text-[11px] font-medium text-slate-500">Predicted Approvals</span>
          <div className="text-lg font-bold text-slate-900 mt-0.5">
            {analysis.approvedCount}{' '}
            <span className="text-xs font-normal text-slate-400">
              ({((analysis.approvedCount / (analysis.total || 1)) * 100).toFixed(1)}%)
            </span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
          <span className="text-[11px] font-medium text-slate-500">Predicted Rejections</span>
          <div className="text-lg font-bold text-slate-900 mt-0.5">
            {analysis.rejectedCount}{' '}
            <span className="text-xs font-normal text-slate-400">
              ({((analysis.rejectedCount / (analysis.total || 1)) * 100).toFixed(1)}%)
            </span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
          <span className="text-[11px] font-medium text-slate-500">Precision</span>
          <div className="text-lg font-bold text-indigo-600 mt-0.5">
            {analysis.metrics.precision}%
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
          <span className="text-[11px] font-medium text-slate-500">Recall (Sensitivity)</span>
          <div className="text-lg font-bold text-indigo-600 mt-0.5">
            {analysis.metrics.recall}%
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
          <span className="text-[11px] font-medium text-slate-500">Simulated F1 Score</span>
          <div className="text-lg font-bold text-indigo-600 mt-0.5">
            {analysis.metrics.f1Score}%
          </div>
        </div>
      </div>

      {/* Analytical Tradeoff Notice */}
      <div className="p-3 rounded-xl bg-indigo-50/60 border border-indigo-200/60 flex items-start gap-2.5 text-xs text-indigo-950">
        <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed text-[11px]">
          <strong>Analytical Threshold Note:</strong> Adjusting the cutoff from 0.50 dynamically trades off <em>Precision</em> (protecting capital from adverse credit defaults) against <em>Recall</em> (capturing creditworthy borrowers). This demonstrates mathematical risk-return sensitivity analysis and does not represent an underwriting rule.
        </p>
      </div>
    </div>
  );
};
