import React from 'react';
import {
  LayoutDashboard,
  Calculator,
  BarChart3,
  Cpu,
  FileDown,
  ShieldCheck,
  CheckCircle2,
  X
} from 'lucide-react';
import { ActiveTab, DatasetStatistics, ModelEvaluationResult } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  isOpen: boolean;
  onClose: () => void;
  stats?: DatasetStatistics | null;
  evaluation?: ModelEvaluationResult | null;
  onDownloadReport: () => void;
  isGeneratingReport: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  isOpen,
  onClose,
  stats,
  evaluation,
  onDownloadReport,
  isGeneratingReport,
}) => {
  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Portfolio overview & analytics',
    },
    {
      id: 'predictor' as ActiveTab,
      label: 'Loan Predictor',
      icon: Calculator,
      description: 'Classify new applications',
    },
    {
      id: 'analysis' as ActiveTab,
      label: 'Loan Analysis',
      icon: BarChart3,
      description: 'Historical records explorer',
    },
    {
      id: 'performance' as ActiveTab,
      label: 'Model Performance',
      icon: Cpu,
      description: 'Metrics & confusion matrix',
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-slate-900 text-slate-100 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-semibold text-base text-white tracking-tight leading-tight">
                Loan Predictor
              </h1>
              <p className="text-xs text-slate-400">In-Browser ML Underwriter</p>
            </div>
          </div>
          <button
            id="close-sidebar-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => {
                  onTabChange(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3.5 px-3.5 py-3 rounded-xl text-left transition-all text-sm font-medium ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <div className="flex flex-col min-w-0">
                  <span className="truncate">{item.label}</span>
                  <span className={`text-[11px] truncate ${isActive ? 'text-indigo-100' : 'text-slate-400'}`}>
                    {item.description}
                  </span>
                </div>
              </button>
            );
          })}
        </nav>

        {/* System & Model Status Widget */}
        <div className="px-4 py-4 border-t border-slate-800/80 bg-slate-950/40">
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Trained Dataset</span>
              <span className="font-medium text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {stats ? `${stats.totalApplications} records` : 'Loading...'}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Best Model</span>
              <span className="font-medium text-indigo-300">
                {evaluation?.bestModelName || 'Training...'}
              </span>
            </div>
            {evaluation && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Validation F1</span>
                <span className="font-semibold text-slate-200">
                  {evaluation.bestModelName === 'Logistic Regression'
                    ? `${evaluation.logisticRegression.metrics.f1Score}%`
                    : `${evaluation.decisionTree.metrics.f1Score}%`}
                </span>
              </div>
            )}
          </div>

          <button
            id="sidebar-download-report-btn"
            onClick={onDownloadReport}
            disabled={isGeneratingReport || !stats}
            className="mt-3 w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <FileDown className="w-4 h-4 text-indigo-400" />
            {isGeneratingReport ? 'Generating PDF...' : 'Download PDF Report'}
          </button>
        </div>
      </aside>
    </>
  );
};
