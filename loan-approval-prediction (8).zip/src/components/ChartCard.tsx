import React from 'react';

interface ChartCardProps {
  id?: string;
  title: string;
  subtitle?: string;
  badge?: string;
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  id,
  title,
  subtitle,
  badge,
  children,
  action,
  className = '',
}) => {
  return (
    <div
      id={id}
      className={`bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 flex flex-col min-w-0 ${className}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900 tracking-tight truncate">
              {title}
            </h2>
            {badge && (
              <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-200/60">
                {badge}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
              {subtitle}
            </p>
          )}
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </div>

      <div className="flex-1 w-full min-w-0">
        {children}
      </div>
    </div>
  );
};
